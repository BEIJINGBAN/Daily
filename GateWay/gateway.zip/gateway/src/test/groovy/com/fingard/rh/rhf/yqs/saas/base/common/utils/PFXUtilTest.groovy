package com.fingard.rh.rhf.yqs.saas.gateway.common.utils

import org.apache.commons.io.FileUtils
import spock.lang.Specification
import spock.lang.Subject

import java.security.PrivateKey

/**
 *
 * @author lihy* @version 1.0  2020/12/10
 */
@Subject(PFXUtil.class)
class PFXUtilTest extends Specification {
//        String pfxPath = "D:\\doc\\接口文档\\杭银分账\\H100006041.pfx";
//        String password = "000000";
//        //私钥：pfx文件中获取私钥对象
//        PrivateKey privateKey = getPrivateKeyByPfx(pfxPath, password);
//        byte[] privateKeyByte = privateKey.getEncoded();
//        String privateKeyStr = Base64.encodeBase64String(privateKeyByte);
//        System.out.println("私钥Base64字符串：" + privateKeyStr);
//
////        //=====私钥Base64字符串转私钥对象
//        PrivateKey privateKey2 = getPrivateKey(privateKeyStr);
//        System.out.println("私钥Base64字符串2：" + Base64.encodeBase64String(privateKey2.getEncoded()));

//        //证书：从pfx文件中获取证书对象
//        X509Certificate certificate = getX509Certificate(pfxPath, password);
//        System.out.println("证书主题：" + certificate.getSubjectDN().getName());
//        String publicKeyStr = Base64.encodeBase64String(certificate.getPublicKey().getEncoded());
//        System.out.println("公钥Base64字符串：" + publicKeyStr);
//        //=====根据公钥Base64字符串获取公钥对象
//        System.out.println("公钥Base64字符串2：" + Base64.encodeBase64String(getPublicKey(publicKeyStr).getEncoded()));
//        //PFX：合成pfx（需要私钥、公钥证书）
//        String savePath = generatorPFX(privateKey, certificate, "1", new File
//                ("C:\\Users\\49383\\Desktop\\文件\\009\\009.pfx"));
//        System.out.println(savePath);

    // MIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQC1xCP8i+PTIxGSWOBvLN1qf7ewy6WHcUF6x1Lk9B7Ii46e5JzInC+rRFHp5avM+oTJH5fHMFwJcrsDgp2cxEdYihPjod3QJQytE0GHf0YJdlz1Xven8Ug7L6Qjm3w3YSZM8TQTF1EjwHPCq7cvFI4CdgMC7bX8ic7NKJgWbh32ZjRTtKCNYchyqSWGUcHr54EyN9sNxyHNQyuppZ8UcYjv7x9eOk6dICOdiaXaufTCpfmLPMLdpZwo2hif+Z/EGNFcMiUxRAWB2mUTa46P1N0hUGVYwM/qpyNqDhQ2uG4CCd1fppPzLXWehNWfanblW8C65Bx8TlThvkgRoQqAmuPLAgMBAAECggEBAKoF8b+PPynFuO8TEcUMy4SOOU43//tktmJZxrGBpLXkzSDWKc4BQxnKS3EltAGGKOVVFw1sr/rqhgKvkC0O8MniRt58D9degK/4vig3plS9khC3p6NBsFYkpz3jeFr5FfGNAjAFdJGjuOTU6QIyEPA+YWzA3KWAZqBDo5f/oylSNG7B/cLVDKTYcwogIQRw+7+JGwCCrb7mNxkHbPWVkbpMZjRBDNO9HBffAhNpSETrGZoH3/H1ggTNFdXlipbaMrEstPeQnH7lvRfHzTJ4jC/iLY/1fjucpmJMcLsTb9AmCFaJyOK97Dx/aU9KDiat5hNLICGc0kzwv86S1hG7BYkCgYEA8+aia4kU5tGNvnJABoYt3YZoL6gpA9MdC7L4PvitsgtqOsuqIsE+z8KCWOPXbKAMBMa23GmSuHqnwGhmYnjQBJ6lZliqPQMdPXz0vGbrT4J1/nTF+9rqaV7e5bK9I/CqWTCWN1Ea2xAc1O5IUqqmsXEgG7LxnDVhhHT63nE0cc8CgYEAvshwk+7v0mZkdBnStBDuka7bKesMwjHwrkJPdS0dLdMVeLM48XI6ayhZuwIN2+AOPg9Jq5CAgCP6zSpaOQdc6+mc8Hjn36x+fW1PcQm28zuY0gurBk1e97ou/3IpeNDEZtqDKoPV0GmAHIastyD6livjzSbVVAMn2wNDQum1GUUCgYBVzBXqmig+Ig0op2waX20W9kcELLVw4Pzgtq5ZCIWhkh5mXGqXGz+LOjM8LboEPjC8JWMCGilAt/T23ELX9QPH/D7Wx+3q1IOes6wr8lBogc4cGtvigtnfAz6JstySHgDuqwbMor09vmdGCCRs4BcPaGoRFFulxaluPPBa+5ulRQKBgHQBmUK6pSUAkdBu60oGiaoX8rf4bteeWkT7mSkc94MnuQSdpeBant8NuBIYW6j5AnAGB7vEr/464oPiXt4SdhQVBxLJ0eSWFIvb7dREHfSkpnYCFkpMvZRQp8c3+bO27dXExMETTO3fWMD/uwHXkcfChE/4bvsYuCFaSInlZfMpAoGANJgp8gXlXOeq6JXxnobLFwv9V+X25iqMy+k6cTG6AFBFS/EMyMzSGrzZ4eKnZFrpsa5NwJCebtBBfy5ivp6Plva895lO+gh5U/RnLcbYqkqU4V1eI3+JJPMFIUV3DoWXakDmzjrgiP+H1/+Z794Dw4yNYppYdARGkYJNKcAH4lw=
    void "test_1"() {
        when:
        String path = "C:\\Users\\lihuayang\\Desktop\\103884402896540.pfx"
        String password = "123456"

        PrivateKey privateKey = PFXUtil.getPrivateKeyByPfx(path, password)
        then:
        String result = new String(Base64.getEncoder().encode(privateKey.getEncoded()))
        println result
    }

    void "test_2"() {
        when:
        File uploadFile = new File("C:\\Users\\lihuayang\\Desktop\\1.txt")
        String ori = FileUtils.readFileToString(uploadFile);
        println "ori:" + ori
        String md5Content = MD5.getMD5ofStr(ori);
        println "md5Content:" + md5Content

        then:
        String sign = RsaSignUtil.rsaSign2(md5Content, "MIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQC1xCP8i+PTIxGSWOBvLN1qf7ewy6WHcUF6x1Lk9B7Ii46e5JzInC+rRFHp5avM+oTJH5fHMFwJcrsDgp2cxEdYihPjod3QJQytE0GHf0YJdlz1Xven8Ug7L6Qjm3w3YSZM8TQTF1EjwHPCq7cvFI4CdgMC7bX8ic7NKJgWbh32ZjRTtKCNYchyqSWGUcHr54EyN9sNxyHNQyuppZ8UcYjv7x9eOk6dICOdiaXaufTCpfmLPMLdpZwo2hif+Z/EGNFcMiUxRAWB2mUTa46P1N0hUGVYwM/qpyNqDhQ2uG4CCd1fppPzLXWehNWfanblW8C65Bx8TlThvkgRoQqAmuPLAgMBAAECggEBAKoF8b+PPynFuO8TEcUMy4SOOU43//tktmJZxrGBpLXkzSDWKc4BQxnKS3EltAGGKOVVFw1sr/rqhgKvkC0O8MniRt58D9degK/4vig3plS9khC3p6NBsFYkpz3jeFr5FfGNAjAFdJGjuOTU6QIyEPA+YWzA3KWAZqBDo5f/oylSNG7B/cLVDKTYcwogIQRw+7+JGwCCrb7mNxkHbPWVkbpMZjRBDNO9HBffAhNpSETrGZoH3/H1ggTNFdXlipbaMrEstPeQnH7lvRfHzTJ4jC/iLY/1fjucpmJMcLsTb9AmCFaJyOK97Dx/aU9KDiat5hNLICGc0kzwv86S1hG7BYkCgYEA8+aia4kU5tGNvnJABoYt3YZoL6gpA9MdC7L4PvitsgtqOsuqIsE+z8KCWOPXbKAMBMa23GmSuHqnwGhmYnjQBJ6lZliqPQMdPXz0vGbrT4J1/nTF+9rqaV7e5bK9I/CqWTCWN1Ea2xAc1O5IUqqmsXEgG7LxnDVhhHT63nE0cc8CgYEAvshwk+7v0mZkdBnStBDuka7bKesMwjHwrkJPdS0dLdMVeLM48XI6ayhZuwIN2+AOPg9Jq5CAgCP6zSpaOQdc6+mc8Hjn36x+fW1PcQm28zuY0gurBk1e97ou/3IpeNDEZtqDKoPV0GmAHIastyD6livjzSbVVAMn2wNDQum1GUUCgYBVzBXqmig+Ig0op2waX20W9kcELLVw4Pzgtq5ZCIWhkh5mXGqXGz+LOjM8LboEPjC8JWMCGilAt/T23ELX9QPH/D7Wx+3q1IOes6wr8lBogc4cGtvigtnfAz6JstySHgDuqwbMor09vmdGCCRs4BcPaGoRFFulxaluPPBa+5ulRQKBgHQBmUK6pSUAkdBu60oGiaoX8rf4bteeWkT7mSkc94MnuQSdpeBant8NuBIYW6j5AnAGB7vEr/464oPiXt4SdhQVBxLJ0eSWFIvb7dREHfSkpnYCFkpMvZRQp8c3+bO27dXExMETTO3fWMD/uwHXkcfChE/4bvsYuCFaSInlZfMpAoGANJgp8gXlXOeq6JXxnobLFwv9V+X25iqMy+k6cTG6AFBFS/EMyMzSGrzZ4eKnZFrpsa5NwJCebtBBfy5ivp6Plva895lO+gh5U/RnLcbYqkqU4V1eI3+JJPMFIUV3DoWXakDmzjrgiP+H1/+Z794Dw4yNYppYdARGkYJNKcAH4lw=");
        println "sign:" + sign
    }
}
