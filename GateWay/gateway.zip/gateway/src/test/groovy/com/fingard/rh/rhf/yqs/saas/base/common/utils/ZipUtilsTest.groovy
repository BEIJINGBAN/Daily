package com.fingard.rh.rhf.yqs.saas.gateway.common.utils

import spock.lang.Specification

/**
 *
 * @author lihy* @version 1.0  2020/12/18
 */
class ZipUtilsTest extends Specification {
    def "test_upZip"() {
        given:
        String fileContent1 = "eJwL8GZmEWHg4OBgKMyYFMiABKSA2MPQAAjMDEwM440MjAwMjQwt4g2M9UoqSnS7d3M2BIg4Vx8MbHly7/vG7YUCxz00IyItujX4Uj7eOaQ+Q6T9AOftNJUsIaZUgws3XkebpLi1C16snfGEL+ygsJKdlHP4/DOBiz5M1zr+R+d27dqnd1T3Bnizc0S6Sb4IBVqdDMQB3oxMIgwI5yHLSTGgA9yODfBmZQOpYARCDyA9F6weANr9QKw=";

        when:
        byte[] decode = Base64.getDecoder().decode(fileContent1.getBytes("utf-8"));
        byte[] bytes = CompressUtil.unCompress(decode);
        byte[] bytes2 = ZipUtils.upZip(bytes);

        then:
        System.out.println(new String(bytes2, "utf-8"));
    }
}
