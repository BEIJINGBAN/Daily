package com.fingard.rh.rhf.yqs.saas.gateway.common.handler;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;


/**
 * @author Ruvik
 * @create 2023/03/30 15:03
 */
public class ThreadPoolHandler {
    /**
     * io为主的线程池
     */
    public static ExecutorService ioTypeThreadPool = new ThreadPoolExecutor(
            2 * Runtime.getRuntime().availableProcessors(),
            2 * Runtime.getRuntime().availableProcessors(),
            0L,
            TimeUnit.MILLISECONDS,
            new LinkedBlockingQueue<>(10000),
            new MessageReject()
    );
}
