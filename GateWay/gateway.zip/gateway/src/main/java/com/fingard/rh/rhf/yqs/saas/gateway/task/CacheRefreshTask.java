package com.fingard.rh.rhf.yqs.saas.gateway.task;

import com.fingard.rh.rhf.yqs.saas.gateway.manager.CacheManager;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.Scheduled;

/**
 * @author Ruvik
 * @create 2022/08/17 15:31
 */
@Configuration
@Slf4j
public class CacheRefreshTask {

    @Autowired
    private CacheManager cacheManager;

    @Scheduled(cron = "0 0/15 * * * ?")
    public void refresh() {
        log.info("缓存刷新任务启动");
        try {
            cacheManager.refreshCache();
        } catch (Exception e) {
            log.error("刷新任务出现异常", e);
        }
    }
}
