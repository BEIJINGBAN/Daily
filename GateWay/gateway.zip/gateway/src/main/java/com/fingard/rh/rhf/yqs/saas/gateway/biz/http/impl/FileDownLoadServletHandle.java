package com.fingard.rh.rhf.yqs.saas.gateway.biz.http.impl;

import cn.hutool.core.util.ObjectUtil;
import cn.hutool.core.util.StrUtil;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.TypeReference;
import com.fingard.rh.rhf.yqs.saas.common.beans.BaseReturnResult;
import com.fingard.rh.rhf.yqs.saas.common.beans.constant.RedisConstant;
import com.fingard.rh.rhf.yqs.saas.common.beans.domain.DoMainConfig;
import com.fingard.rh.rhf.yqs.saas.common.beans.file.FileInfoBean;
import com.fingard.rh.rhf.yqs.saas.common.beans.gateway.InterfaceBean;
import com.fingard.rh.rhf.yqs.saas.common.enums.FileInterFaceTypeEnum;
import com.fingard.rh.rhf.yqs.saas.common.enums.MsgCodeEnum;
import com.fingard.rh.rhf.yqs.saas.common.enums.YesOrNoEnum;
import com.fingard.rh.rhf.yqs.saas.gateway.biz.http.FileServletHandle;
import com.fingard.rh.rhf.yqs.saas.gateway.dto.FtpInfoDTO;
import com.fingard.rh.rhf.yqs.saas.gateway.dto.UrlHandleParam;
import com.fingard.rh.rhf.yqs.saas.gateway.exception.GatewayException;
import com.fingard.rh.rhf.yqs.saas.gateway.util.CommonUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

/**
 * 文件下载接口
 *
 * @author Ruvik
 * @create 2022/07/25 11:06
 */
@Service
@Slf4j
public class FileDownLoadServletHandle extends FileServletHandle {

    @Override
    public boolean isSupport(UrlHandleParam urlHandleParam) {
        InterfaceBean interfaceBean = urlHandleParam.getInterfaceBean();
        return StrUtil.equals(interfaceBean.getIsFileInterface(), YesOrNoEnum.YES.getValue()) &&
                StrUtil.equals(interfaceBean.getFileInterfaceType(), FileInterFaceTypeEnum.DOWNLOAD.getValue());
    }

    @Override
    public void handleUrlReq(UrlHandleParam urlHandleParam) {
        callDubbo(urlHandleParam, zkUrl, getJsonParam(urlHandleParam));
    }

    @Override
    public void dealTheDubboResult(Object result, UrlHandleParam urlHandleParam) {
        BaseReturnResult<FileInfoBean> fileInfoBeanBaseReturnResult = JSON.parseObject(JSON.toJSONString(result), new TypeReference<BaseReturnResult<FileInfoBean>>(FileInfoBean.class) {
        });
        if (ObjectUtil.notEqual(fileInfoBeanBaseReturnResult.getCode(), MsgCodeEnum.Success.getValue())) {
            log.error("业务系统返回失败");
            throw new GatewayException(fileInfoBeanBaseReturnResult.getInfo());
        }
        FileInfoBean fileInfo = fileInfoBeanBaseReturnResult.getObject();
        FtpInfoDTO ftpInfoDTO = getFTPInfo(cacheManager, fileInfo.getFtpKey());
        try {
            if (!cacheManager.cacheBucketExist(RedisConstant.YQS_DOMAINCONFIG_CACHE)) {
                log.error("文件下载获取域名配置失败");
                throw new GatewayException("文件下载获取域名配置失败");
            }
            DoMainConfig mainConfig = cacheManager.getCache(RedisConstant.YQS_DOMAINCONFIG_CACHE);
            if (null == mainConfig) {
                log.error("获取域名配置失败");
                throw new RuntimeException();
            }
            writeResult(BaseReturnResult.getSuccessResult(CommonUtil.getPictureUrl(fileInfo, mainConfig)), urlHandleParam.getHttpServletResponse());
        } finally {
            disconnectFtp(ftpInfoDTO.getFtpClient());
        }
    }
}
