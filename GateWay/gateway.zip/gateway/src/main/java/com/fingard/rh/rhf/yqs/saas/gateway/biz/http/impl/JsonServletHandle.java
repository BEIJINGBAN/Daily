package com.fingard.rh.rhf.yqs.saas.gateway.biz.http.impl;

import cn.hutool.core.util.StrUtil;
import com.fingard.rh.rhf.yqs.saas.common.beans.gateway.InterfaceBean;
import com.fingard.rh.rhf.yqs.saas.common.enums.HttpRequestMethodEnum;
import com.fingard.rh.rhf.yqs.saas.common.enums.YesOrNoEnum;
import com.fingard.rh.rhf.yqs.saas.gateway.biz.http.NormalServletHandle;
import com.fingard.rh.rhf.yqs.saas.gateway.dto.UrlHandleParam;
import com.fingard.rh.rhf.yqs.saas.gateway.manager.CacheManager;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;

/**
 * @author Ruvik
 * @create 2022/09/02 15:31
 */
@Service
@Slf4j
public class JsonServletHandle extends NormalServletHandle {

    @Value("${dubbo.registry.address}")
    private String zkUrl;

    @Autowired
    private CacheManager cacheManager;

    @Override
    public boolean isSupport(UrlHandleParam urlHandleParam) {
        InterfaceBean interfaceBean = urlHandleParam.getInterfaceBean();
        return StrUtil.equals(interfaceBean.getIsFileInterface(), YesOrNoEnum.NO.getValue()) &&
                !StrUtil.equals(interfaceBean.getIsOutside(), YesOrNoEnum.YES.getValue()) &&
                StrUtil.equals(HttpRequestMethodEnum.POST.getValue(), interfaceBean.getRequestType()) &&
                StrUtil.equals(interfaceBean.getContentType(), MediaType.APPLICATION_JSON_VALUE);
    }

    @Override
    public void handleUrlReq(UrlHandleParam urlHandleParam) {
        Object result = getJsonParam(urlHandleParam);
        String mchId = super.getMchId(result);
        String zkAddress = getZkAddress(zkUrl, mchId, urlHandleParam, cacheManager);
        callDubbo(urlHandleParam, zkAddress, result);
    }

    @Override
    public void dealTheDubboResult(Object result, UrlHandleParam urlHandleParam) {
        writeResult(result, urlHandleParam.getHttpServletResponse());
    }
}
