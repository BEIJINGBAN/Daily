package com.fingard.rh.rhf.yqs.saas.gateway.util;

import cn.hutool.core.util.StrUtil;
import sun.misc.BASE64Decoder;

import java.security.KeyFactory;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.Signature;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.*;

/**
 * @author Don
 * @date 2020/9/21.
 */
public final class SignUtil {

    public static String genSignContentWithSalt(Map<String, Object> map, String saltVal) {
        List<String> contentHolder = new ArrayList<>();
        genSignContent(map, contentHolder);

        contentHolder.add(saltVal);
        return String.join("_", contentHolder);
    }

    public static void genSignContent(Map<String, Object> map, List<String> contentHolder) {
        Map<String, Object> treeMapTemp = new TreeMap<>(map);

        for (Map.Entry<String, Object> entry : treeMapTemp.entrySet()) {
            if ("sign".equals(entry.getKey())) {
                continue;
            }
            if (entry.getValue() instanceof Map) {
                genSignContent((Map<String, Object>) entry.getValue(), contentHolder);
            } else if (entry.getValue() instanceof String && !"class".equals(entry.getKey())) {
                addIfNotBlank(entry.getValue().toString(), contentHolder);
            } else if (entry.getValue() instanceof Integer) {
                addIfNotBlank(entry.getValue().toString(), contentHolder);
            } else if (entry.getValue() instanceof Long) {
                addIfNotBlank(entry.getValue().toString(), contentHolder);
            } else if (entry.getValue() instanceof List) {
                List<Map<String, Object>> list = (List<Map<String, Object>>) entry.getValue();
                for (Map<String, Object> item : list) {
                    genSignContent(item, contentHolder);
                }
            } else {

            }
        }
    }

    private static void addIfNotBlank(String val, List<String> list) {
        if (StrUtil.isNotBlank(val)) {
            list.add(val);
        }
    }

    public static String rsaSign(String content, String privateKey, String signRsaAlgorithm, String inputCharset) {
        try {
            PKCS8EncodedKeySpec priPKCS8 = new PKCS8EncodedKeySpec(Base64.getDecoder().decode(privateKey));
            KeyFactory keyf = KeyFactory.getInstance("RSA");
            PrivateKey priKey = keyf.generatePrivate(priPKCS8);

            Signature signature = Signature.getInstance(signRsaAlgorithm);

            signature.initSign(priKey);
            signature.update(content.getBytes(inputCharset));

            byte[] signed = signature.sign();

            return new String(Base64.getEncoder().encode(signed), inputCharset);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public static boolean rsaVerify(String content, String sign, String publicKey, String signRsaAlgorithm, String inputCharset) {
        try {
            KeyFactory keyFactory = KeyFactory.getInstance("RSA");
            byte[] encodedKey = Base64.getDecoder().decode(publicKey);
            PublicKey pubKey = keyFactory.generatePublic(new X509EncodedKeySpec(encodedKey));

            Signature signature =
                    Signature.getInstance(signRsaAlgorithm);

            signature.initVerify(pubKey);
            signature.update(content.getBytes(inputCharset));
            return signature.verify(Base64.getDecoder().decode(sign));
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public static boolean icbcRsaVerify(String content, String sign, String publicKey, String signRsaAlgorithm, String inputCharset) {
        try {
            KeyFactory keyFactory = KeyFactory.getInstance("RSA");
            byte[] encodedKey = Base64.getDecoder().decode(publicKey);
            PublicKey pubKey = keyFactory.generatePublic(new X509EncodedKeySpec(encodedKey));

            Signature signature =
                    Signature.getInstance(signRsaAlgorithm);

            signature.initVerify(pubKey);
            signature.update(content.getBytes(inputCharset));

            return signature.verify(new BASE64Decoder().decodeBuffer(sign));
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
}
