package com.fingard.rh.rhf.yqs.saas.gateway.exception;

import lombok.Getter;

/**
 * @author Ruvik
 * @create 2023/02/07 13:50
 */
public class SignErrorException extends RuntimeException {
    @Getter
    private String returnMsg;

    @Getter
    private String mchId;

    public SignErrorException(String returnMsg, String mchId) {
        this.returnMsg = returnMsg;
        this.mchId = mchId;
    }
}
