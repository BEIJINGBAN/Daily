package com.fingard.rh.rhf.yqs.saas.gateway.conf;

import org.apache.dubbo.config.ReferenceConfigBase;
import org.apache.dubbo.config.utils.ReferenceConfigCache;

/**
 * @author Ruvik
 * @create 2022/10/08 16:41
 */
public class GateWayDubboKeyGenerator implements ReferenceConfigCache.KeyGenerator {
    @Override
    public String generateKey(ReferenceConfigBase<?> referenceConfig) {
        return referenceConfig.getRegistry().getAddress() + referenceConfig.getGroup() + referenceConfig.getVersion() + referenceConfig.getInterface() + referenceConfig.getTimeout();
    }
}
