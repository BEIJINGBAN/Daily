package com.fingard.rh.rhf.yqs.saas.gateway.common.handler;

import lombok.extern.slf4j.Slf4j;

import java.util.concurrent.RejectedExecutionHandler;
import java.util.concurrent.ThreadPoolExecutor;


/**
 * @author Ruvik
 * @create 2023/03/30 14:59
 */
@Slf4j
public class MessageReject implements RejectedExecutionHandler {
    @Override
    public void rejectedExecution(Runnable r, ThreadPoolExecutor executor) {
        MessageTask messageTask = (MessageTask) r;
        log.error("消息推送拒绝任务参数:[{}]", messageTask.getMessage());
    }
}
