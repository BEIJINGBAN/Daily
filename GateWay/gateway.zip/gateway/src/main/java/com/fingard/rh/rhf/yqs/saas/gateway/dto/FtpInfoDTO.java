package com.fingard.rh.rhf.yqs.saas.gateway.dto;

import com.fingard.rh.rhf.yqs.saas.common.beans.ftp.FTPConfigBean;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.apache.commons.net.ftp.FTPClient;

import java.io.Serializable;

/**
 * ftp信息封装类
 *
 * @author Ruvik
 * @create 2022/08/16 14:27
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class FtpInfoDTO implements Serializable {

    private static final long serialVersionUID = -4103982970853259753L;

    /**
     * ftp连接
     */
    private FTPClient ftpClient;

    /**
     * redis存的ftp配置
     */
    private FTPConfigBean ftpConfigBean;
}
