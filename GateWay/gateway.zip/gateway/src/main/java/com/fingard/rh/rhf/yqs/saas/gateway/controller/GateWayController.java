package com.fingard.rh.rhf.yqs.saas.gateway.controller;

import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.mvc.ServletWrappingController;

/**
 * @author Ruvik
 * @create 2022/07/20 15:02
 */
@Component
public class GateWayController extends ServletWrappingController {

    private final static String servletName = "gateWayServlet";

    public GateWayController() {
        setServletClass(GateWayServlet.class);
        setServletName(servletName);
        setSupportedMethods(HttpMethod.GET.name(), HttpMethod.POST.name());
        setRequireSession(false);
    }
}
