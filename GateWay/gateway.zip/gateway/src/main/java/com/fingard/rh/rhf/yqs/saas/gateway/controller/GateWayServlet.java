package com.fingard.rh.rhf.yqs.saas.gateway.controller;

import cn.hutool.core.util.ObjectUtil;
import cn.hutool.core.util.StrUtil;
import com.alibaba.fastjson.JSON;
import com.fingard.rh.rhf.yqs.saas.common.beans.BaseReturnResult;
import com.fingard.rh.rhf.yqs.saas.common.beans.cache.LocalCache;
import com.fingard.rh.rhf.yqs.saas.common.beans.constant.RedisConstant;
import com.fingard.rh.rhf.yqs.saas.common.beans.gateway.InterfaceBean;
import com.fingard.rh.rhf.yqs.saas.common.beans.gateway.OnlineCustomInterfaceBean;
import com.fingard.rh.rhf.yqs.saas.common.beans.open.OpenApiBaseResponse;
import com.fingard.rh.rhf.yqs.saas.common.beans.user.LogRecord;
import com.fingard.rh.rhf.yqs.saas.common.beans.user.UserContext;
import com.fingard.rh.rhf.yqs.saas.common.beans.user.UserInfo;
import com.fingard.rh.rhf.yqs.saas.common.enums.open.OpenApiResultCodeEnum;
import com.fingard.rh.rhf.yqs.saas.gateway.biz.http.ServletHandle;
import com.fingard.rh.rhf.yqs.saas.gateway.biz.http.ServletHandleFactory;
import com.fingard.rh.rhf.yqs.saas.gateway.common.constant.GateWayCoreConstant;
import com.fingard.rh.rhf.yqs.saas.gateway.common.enums.AuthEnum;
import com.fingard.rh.rhf.yqs.saas.gateway.common.enums.SystemSignEnum;
import com.fingard.rh.rhf.yqs.saas.gateway.dto.UniversalDTO;
import com.fingard.rh.rhf.yqs.saas.gateway.dto.UrlHandleParam;
import com.fingard.rh.rhf.yqs.saas.gateway.exception.EnterpriseException;
import com.fingard.rh.rhf.yqs.saas.gateway.exception.GatewayException;
import com.fingard.rh.rhf.yqs.saas.gateway.exception.SignErrorException;
import com.fingard.rh.rhf.yqs.saas.gateway.manager.CacheManager;
import com.fingard.rh.rhf.yqs.saas.gateway.util.CommonUtil;
import com.fingard.rh.rhf.yqs.saas.gateway.util.IOUtil;
import com.fingard.rh.rhf.yqs.saas.gateway.util.IpUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.dubbo.rpc.RpcContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.util.Assert;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StopWatch;
import org.springframework.web.context.support.WebApplicationContextUtils;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * @author Ruvik
 * @create 2022/07/20 15:03
 */
@Slf4j
public class GateWayServlet extends HttpServlet {

    private static final long serialVersionUID = -3374242278843351500L;

    @Value("${dubbo.registry.address}")
    private String zkUrl;

    @Value("${yqs.saas.gateway.mark}")
    private String mark;

    @Autowired
    private ServletHandleFactory servletHandleFactory;

    @Autowired
    private CacheManager cacheManager;

    @Override
    public void init(ServletConfig config) throws ServletException {
        super.init(config);
        WebApplicationContextUtils
                .getWebApplicationContext(getServletContext())
                .getAutowireCapableBeanFactory().autowireBean(this);
    }

    /**
     * 处理请求入口
     **/
    @Override
    public void service(ServletRequest servletRequest, ServletResponse servletResponse) {
        StopWatch stopWatch = new StopWatch();
        stopWatch.start();
        HttpServletRequest httpServletRequest = (HttpServletRequest) servletRequest;
        HttpServletResponse httpServletResponse = (HttpServletResponse) servletResponse;
        try {
            if (StrUtil.equals(GateWayCoreConstant.REFRESH_CACHE_URL, httpServletRequest.getServletPath())) {
                refreshCache(httpServletResponse);
            } else {
                handleUrl(httpServletRequest, httpServletResponse);
            }
        } catch (SignErrorException signatureException) {
            log.error("网关系统出现异常", signatureException);
            writeResult(OpenApiBaseResponse.gatewayFail(OpenApiResultCodeEnum.VERIFY_FAIL, "验签失败"), httpServletResponse);
        } catch (EnterpriseException enterpriseException) {
            log.error("网关系统出现异常", enterpriseException);
            if (enterpriseException.getCause() instanceof SignErrorException) {
                writeResult(OpenApiBaseResponse.gatewayFail(OpenApiResultCodeEnum.VERIFY_FAIL, "验签失败"), httpServletResponse);
            } else {
                writeResult(OpenApiBaseResponse.gatewayFail(OpenApiResultCodeEnum.OTHER, "处理异常"), httpServletResponse);
            }
        } catch (GatewayException gatewayException) {
            log.error("网关系统出现异常", gatewayException);
            writeResult(BaseReturnResult.getFailResult(gatewayException.getReturnMsg()), httpServletResponse);
        } catch (Exception e) {
            log.error("网关系统出现未知异常", e);
            writeResult(BaseReturnResult.getFailResult(), httpServletResponse);
        } finally {
            stopWatch.stop();
            log.info("当前url:[{}],执行时间[{}]", httpServletRequest.getServletPath(), stopWatch.getTotalTimeSeconds());
        }
    }

    private void checkPermission(InterfaceBean interFaceBean, HttpServletRequest httpServletRequest,
                                 String providerAddress, UserInfo userInfo) {
        if (StrUtil.equals(AuthEnum.SHOULD_AUTH.getValue(), interFaceBean.getIsAuthentication())) {
            Object result = CommonUtil.generic(genCheckInterFaceBean(), zkUrl, new String[]{"java.lang.String"}, new Object[]{httpServletRequest.getServletPath()}, providerAddress, userInfo);
            if (ObjectUtil.isNull(result)) {
                log.error("当前url:[{}],接口权限结果为空", httpServletRequest.getServletPath());
                throw new GatewayException("接口权限结果为空");
            }
            BaseReturnResult<Void> baseReturnResult = CommonUtil.genResult(result, Void.class);
            if (!baseReturnResult.isSuccess()) {
                log.error("当前url:[{}],接口权限校验失败", httpServletRequest.getServletPath());
                throw new GatewayException(baseReturnResult.getInfo());
            }
        }
    }

    private boolean judgeTokenExists(InterfaceBean interfaceBean, String token, HttpServletRequest httpServletRequest) {
        if (StrUtil.equals(AuthEnum.SHOULD_AUTH.getValue(), interfaceBean.getIsAuthentication())) {
            if (StrUtil.isEmpty(token) || GateWayCoreConstant.SEGMENT_NULL.equalsIgnoreCase(token)) {
                return false;
            }
            return cacheManager.cacheBucketExist(RedisConstant.tokenKey(token));
        } else if (StrUtil.equals(AuthEnum.REGULAR_AUTH.getValue(), interfaceBean.getIsAuthentication())) {
            List<OnlineCustomInterfaceBean> listOnlineCustomInterfaceBean = cacheManager.getCache(RedisConstant.YQS_ONLINE_CUSTOM_INTERFACE_CACHE);
            if (CollectionUtils.isEmpty(listOnlineCustomInterfaceBean)) {
                log.error("当前url:[{}],验证数据不存在", httpServletRequest.getServletPath());
                return false;
            }
            String ip = IpUtil.getIpAddr(httpServletRequest);
            if (StrUtil.isEmpty(ip)) {
                log.error("当前url:[{}],ip数据不存在", httpServletRequest.getServletPath());
                return false;
            }
            Map<String, String> mapOnlineCustomInterfaceMap = listOnlineCustomInterfaceBean.stream().collect(Collectors.toMap(OnlineCustomInterfaceBean::getIp, OnlineCustomInterfaceBean::getToken));
            if (!mapOnlineCustomInterfaceMap.containsKey(ip) ||
                    !StrUtil.equals(mapOnlineCustomInterfaceMap.get(ip), token)) {
                log.error("当前url:[{}],ip[{}]和token[{}]不一致", httpServletRequest.getServletPath(), ip, token);
                return false;
            }
        } else if (StrUtil.equals(AuthEnum.TOKEN_AUTH.getValue(), interfaceBean.getIsAuthentication())) {
            if (StrUtil.isBlank(token) || GateWayCoreConstant.SEGMENT_NULL.equalsIgnoreCase(token)) {
                return false;
            }
        } else {
            log.warn("url:[{}]请求未做token校验", httpServletRequest.getServletPath());
        }
        return true;
    }

    /**
     * 获取校验的api
     *
     * @return
     */
    private InterfaceBean genCheckInterFaceBean() {
        LocalCache localCache = cacheManager.getLocalCache();
        return (InterfaceBean) localCache.getCache(RedisConstant.urlKey(GateWayCoreConstant.CHECK_PERMISSION_URL));
    }

    private void writeResult(BaseReturnResult<?> baseReturnResult, HttpServletResponse httpServletResponse) {
        IOUtil.writeResult(JSON.toJSONString(baseReturnResult), httpServletResponse);
    }

    private void writeResult(OpenApiBaseResponse baseReturnResult, HttpServletResponse httpServletResponse) {
        IOUtil.writeResult(JSON.toJSONString(baseReturnResult), httpServletResponse);
    }

    private void setInterfaceBean(InterfaceBean interfaceBean, HttpServletRequest httpServletRequest) {
        interfaceBean.setContentType(httpServletRequest.getContentType());
        interfaceBean.setRequestType(httpServletRequest.getMethod());
    }

    private UserInfo getUserInfoFromRedis(String key) {
        if (!cacheManager.cacheBucketExist(key)) {
            log.error("key[{}],获取用户信息为空", key);
            return null;
        }
        return cacheManager.getCache(key);
    }


    private InterfaceBean getInterfaceBeanCacheData(String key) {
        LocalCache localCache = cacheManager.getLocalCache();
        if (localCache.containsCacheKey(key)) {
            return (InterfaceBean) localCache.getCache(key);
        } else {
            UniversalDTO universalDTO = CommonUtil.judgeUniversal(key, localCache);
            if (universalDTO.isExist() && localCache.containsCacheKey(universalDTO.getKey())) {
                return (InterfaceBean) localCache.getCache(universalDTO.getKey());
            }
        }

        if (!cacheManager.cacheBucketExist(key)) {
            log.error("网关urlkey:[{}]没有找到缓存", key);
            throw new RuntimeException();
        }
        InterfaceBean interFaceBean = cacheManager.getCache(key);
        Assert.notNull(interFaceBean, String.format("网关urlkey:[%s]获取缓存失败", key));
        localCache.setCache(key, interFaceBean);
        return interFaceBean;
    }

    private void refreshCache(HttpServletResponse servletResponse) {
        cacheManager.refreshCache();
        writeResult(BaseReturnResult.getSuccess("刷新成功"), servletResponse);
    }

    private void handleUrl(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse) {
        InterfaceBean interfaceBean = getInterfaceBeanCacheData(RedisConstant.urlKey(httpServletRequest.getServletPath()));
        log.info("请求的类型:[{}],[{}],[{}]", httpServletRequest.getContentType(), httpServletRequest.getServletPath(), httpServletRequest.getMethod());
        setInterfaceBean(interfaceBean, httpServletRequest);
        String token = httpServletRequest.getHeader(GateWayCoreConstant.TOKEN_FIELD);
        // 没有登录就前置让前段去登录
        if (!judgeTokenExists(interfaceBean, token, httpServletRequest)) {
            log.error("网关token校验失败,请求路径:[{}]", httpServletRequest.getServletPath());
            writeResult(BaseReturnResult.notLogin(), httpServletResponse);
            return;
        }
        //实际上应该是找服务端地址
        String providerAddress = httpServletRequest.getHeader(GateWayCoreConstant.CONSUMER_ADDRESS_FIELD);
        UserInfo userInfo = getUserInfoFromRedis(RedisConstant.tokenKey(token));
        UrlHandleParam urlHandleParam = UrlHandleParam.builder()
                .httpServletRequest(httpServletRequest)
                .httpServletResponse(httpServletResponse)
                .interfaceBean(interfaceBean)
                .providerAddress(providerAddress)
                .userInfo(userInfo)
                .build();
        // 校验辉山的代码
        checkHuiShanCasLogin(httpServletRequest, userInfo);
        checkPermission(interfaceBean, httpServletRequest, providerAddress, userInfo);
        ServletHandle servletHandle = servletHandleFactory.getServletHandle(urlHandleParam);
        if (ObjectUtil.isNull(servletHandle)) {
            log.error("网关获取实现handle失败,url:[{}]", httpServletRequest.getServletPath());
            throw new RuntimeException();
        }
        setIpAddress(IpUtil.getIpAddr(httpServletRequest));
        servletHandle.handleUrlReq(urlHandleParam);
    }

    private LogRecord generateRecordLog(HttpServletRequest httpServletRequest) {
        LogRecord logRecord = new LogRecord();
        //获取请求参数的remark对象
        String[] logRecords = httpServletRequest.getParameterValues("logRecord");
        if (logRecords != null && logRecords.length > 0) {
            JSON.parseObject(logRecords[0], LogRecord.class);
        }
        return logRecord;
    }


    /**
     * 校验辉山单点登录，如果是辉山的并且如果访问登录接口&&有token就返回异常
     */
    private void checkHuiShanCasLogin(HttpServletRequest httpServletRequest, UserInfo userInfo) {
        String systemSign = httpServletRequest.getHeader(GateWayCoreConstant.SYSTEM_SIGN);
        if (SystemSignEnum.YUE_XIU_HUI_SHAN.getValue().equals(systemSign) && ObjectUtil.isNotNull(userInfo)) {
            //如果是辉山的并且如果访问登录接口&&有token就返回异常
            boolean result = (GateWayCoreConstant.ENV_MARK_UAT.equals(mark) &&
                    GateWayCoreConstant.UAT_HUI_SHAN_LOGIN.equals(httpServletRequest.getServletPath())) ||
                    (!GateWayCoreConstant.ENV_MARK_UAT.equals(mark) &&
                            GateWayCoreConstant.HUI_SHAN_LOGIN.equals(httpServletRequest.getServletPath()));
            if (result) {
                throw new GatewayException("登录失败");
            }
        }
    }

    public static void setIpAddress(String ipAddress) {
        if (StrUtil.isNotEmpty(ipAddress)) {
            RpcContext.getContext().setAttachment(UserContext.THREAD_ATTRIBUTE_IP_KEY, ipAddress);
        }
    }
}
