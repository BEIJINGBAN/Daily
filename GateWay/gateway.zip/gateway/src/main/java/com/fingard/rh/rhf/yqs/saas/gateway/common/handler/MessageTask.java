package com.fingard.rh.rhf.yqs.saas.gateway.common.handler;

import cn.hutool.core.util.ObjectUtil;
import cn.hutool.core.util.StrUtil;
import com.fingard.rh.rhf.yqs.saas.gateway.common.constant.GateWayCoreConstant;
import lombok.extern.slf4j.Slf4j;
import org.redisson.api.RLock;
import org.redisson.api.RSet;

import javax.websocket.RemoteEndpoint;
import javax.websocket.Session;
import java.util.concurrent.Future;


/**
 * @author Ruvik
 * @create 2023/03/30 15:01
 */
@Slf4j
public class MessageTask implements Runnable {

    private final Session session;

    private final RSet<String> rQueue;

    private final String message;

    private final String userId;

    private RLock rLock;


    public MessageTask(Session session, RSet<String> rQueue, String message, String userId, RLock rLock) {
        this.session = session;
        this.rQueue = rQueue;
        this.message = message;
        this.userId = userId;
        this.rLock = rLock;
    }

    public MessageTask(Session session, String message, String userId) {
        this.session = session;
        this.message = message;
        this.userId = userId;
        this.rQueue = null;
    }

    @Override
    public void run() {
        boolean result = false;
        try {
            if (ObjectUtil.isNotNull(rLock)) {
                result = rLock.tryLock();
            }
            sendMessage();
        } catch (Exception e) {
            log.error("消息任务出现异常", e);
        } finally {
            if (result && ObjectUtil.isNotNull(rLock)) {
                rLock.unlock();
            }
        }
    }

    public String getMessage() {
        return message;
    }

    /**
     * 发送消息要有回馈机制。成功的消息将会移除队列
     */
    private void sendMessage() {
        synchronized (session) {
            if (session.isOpen()) {
                if (!StrUtil.equals(GateWayCoreConstant.ACK_MARK, message)) {
                    log.info("当前在线用户为：给用户[{}]所属SESSION[{}]发送信息，内容为：[{}]",
                            userId, session.getId(), message);
                }
                RemoteEndpoint.Async asyncHandle = session.getAsyncRemote();
                //消息2000ms超时
                asyncHandle.setSendTimeout(2000);
                Future<Void> tracker = asyncHandle.sendText(message);
                try {
                    tracker.get();
                    if (ObjectUtil.isNotNull(rQueue)) {
                        rQueue.remove(message);
                    }
                } catch (Exception e) {
                    log.error("消息发送超时:[{}]", message);
                    log.error("消息发送错误", e);
                }
            } else {
                log.error("推送消息session没有open");
            }
        }
    }
}
