package com.fingard.rh.rhf.yqs.saas.gateway.biz.http;

import cn.hutool.core.util.ObjectUtil;
import cn.hutool.core.util.StrUtil;
import com.fingard.rh.rhf.yqs.saas.gateway.common.constant.GateWayCoreConstant;
import com.fingard.rh.rhf.yqs.saas.gateway.common.handler.MessageTask;
import com.fingard.rh.rhf.yqs.saas.gateway.common.handler.ThreadPoolHandler;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.redisson.api.RLock;
import org.redisson.api.RSet;
import org.redisson.api.RedissonClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.websocket.*;
import javax.websocket.server.PathParam;
import javax.websocket.server.ServerEndpoint;
import java.time.LocalDateTime;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

/** 测试环境和生产的
 * @author Ruvik
 * @create 2022/10/11 14:28
 */
@Slf4j
@Component
@ServerEndpoint(value = "/websocket/yqs/message/{userId}")
public class PushMessageService {

    private static RedissonClient redissonClient;

    @Autowired
    public void setRedissonClient(RedissonClient redissonClient) {
        PushMessageService.redissonClient = redissonClient;
    }


    private static final Map<String, Session> clients = new ConcurrentHashMap<>();

    /**
    * 同一个用户只能同时在一个客户端登录
    * @param
    * @return void
    * @date 2022/12/6
    */
    @OnOpen
    public synchronized void onOpen(@PathParam("userId") String userId, Session session) {
        clients.put(userId, session);
        log.info("用户[{}]在[{}]连接到服务器,SESSION[{}],当前在线客户端数:{}", userId, LocalDateTime.now(), session.getId(), clients.keySet().size());
    }

    @OnClose
    public synchronized void onClose(@PathParam("userId") String userId, Session session) {
        if (clients.containsKey(userId)) {
            Session currentSession = clients.get(userId);
            if (StrUtil.equals(session.getId(), currentSession.getId())) {
                clients.remove(userId);
                log.info("用户[{}]所属SESSION[{}]断开连接", userId, session.getId());
            }
        }
    }

    @OnMessage
    public synchronized void onMessage(String message) {
        log.info("webSocket后台收到消息：[{}]", message);
        if (clients.containsKey(message)) {
            Session session = clients.get(message);
            ThreadPoolHandler.ioTypeThreadPool.execute(new MessageTask(session, GateWayCoreConstant.ACK_MARK, message));
            RSet<String> userQueue = getSet(message);
            if (!userQueue.isEmpty()) {
                // 获取所有的消息。减少redis交互
                Set<String> listMessage = userQueue.readAll();
                log.info("重发的消息:[{}]", listMessage);
                for (String messageData : listMessage) {
                    ThreadPoolHandler.ioTypeThreadPool.execute(new MessageTask(session, userQueue, messageData, message, getLock(messageData)));
                }
            }
        } else {
            log.error("心跳未找到session");
        }
    }

    @OnError
    public void onError(Session session, Throwable error) {
        log.error("well-known Error: " + session.getId(), error);
    }

    /**
     * 新需求要求所有当前userId登录的短都需要接收到消息
     *
     * @param userId
     * @param message
     */
    public void sendMsg(String userId, String message) {
        // 提前插入redis中
        RSet<String> userQueue = getSet(userId);
        setMessage(userQueue, message);
        if (clients.containsKey(userId)) {
            Session session = clients.get(userId);
            final String allClientsStr = clients.toString();
            if (ObjectUtil.isNotNull(session)) {
                try {
                    if (session.isOpen()) {
                        log.info("远程当前在线用户为：[{}]给用户[{}]所属SESSION[{}]发送信息，内容为：[{}]",
                                allClientsStr, userId, session.getId(), message);
                        ThreadPoolHandler.ioTypeThreadPool.execute(new MessageTask(session, userQueue, message, userId, getLock(message)));
                    }
                } catch (Exception e) {
                    log.error(String.format("给用户[{}]SESSION[{}]发送消息异常，消息内容为：[{}]",
                            userId, session.getId(), message), e);
                }
            }
        } else {
            log.error("当前用户不存在session:[{}]", userId);
        }
    }


    /**
     * 如果超过最大集合数就开始丢弃
     *
     * @param queue
     * @param message
     */
    private void setMessage(RSet<String> queue, String message) {
        log.info("添加到队列的数据:[{}],[{}]", queue, message);
        if (queue.size() < GateWayCoreConstant.MAX_QUEUE) {
            queue.add(message);
        } else {
            log.error("无法添加的消息:[{}]", message);
        }
    }

    private RSet<String> getSet(String userId) {
        return redissonClient.getSet(GateWayCoreConstant.getMessageQueue(userId));
    }


    private RLock getLock(String message) {
        return redissonClient.getLock(GateWayCoreConstant.getMessageLock(message));
    }
}
