package com.fingard.rh.rhf.yqs.saas.gateway.util;

import lombok.extern.slf4j.Slf4j;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

/**
 * @author Don
 * @date 2022/11/9.
 */
@Slf4j
public final class IOUtil {

    public static void writeResult(String result, HttpServletResponse httpServletResponse) {
        httpServletResponse.setContentType("application/json;charset=utf-8");
        try (PrintWriter printWriter = httpServletResponse.getWriter()) {
            printWriter.write(result);
            printWriter.flush();
        } catch (IOException ioEx) {
            //写不出去，抛出来没有意义，所以这里打印日志记录错误
            log.error("输出流发生异常", ioEx);
        }
    }
}
