package com.fingard.rh.rhf.yqs.saas.gateway.conf;

import com.fingard.rh.rhf.yqs.saas.common.annotation.amt.Penny2YuanAndThousand;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.socket.server.standard.ServerEndpointExporter;

/**
 * @author Ruvik
 * @create 2022/07/20 15:02
 */
@Configuration
public class GateWayConfig {

    @Bean
    public ServerEndpointExporter serverEndpointExporter() {
        return new ServerEndpointExporter();
    }

    @Bean
    public Penny2YuanAndThousand penny2YuanAndThousand() {
        return new Penny2YuanAndThousand();
    }
}
