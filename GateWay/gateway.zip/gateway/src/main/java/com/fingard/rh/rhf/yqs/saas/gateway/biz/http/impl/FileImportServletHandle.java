package com.fingard.rh.rhf.yqs.saas.gateway.biz.http.impl;

import cn.hutool.core.util.StrUtil;
import com.alibaba.fastjson.JSON;
import com.fingard.rh.rhf.yqs.saas.common.beans.BaseReturnResult;
import com.fingard.rh.rhf.yqs.saas.common.beans.constant.CoreConstant;
import com.fingard.rh.rhf.yqs.saas.common.beans.file.FileInfoBean;
import com.fingard.rh.rhf.yqs.saas.common.beans.gateway.InterfaceBean;
import com.fingard.rh.rhf.yqs.saas.common.enums.FileInterFaceTypeEnum;
import com.fingard.rh.rhf.yqs.saas.common.enums.HttpRequestMethodEnum;
import com.fingard.rh.rhf.yqs.saas.common.enums.YesOrNoEnum;
import com.fingard.rh.rhf.yqs.saas.common.util.FtpUtil;
import com.fingard.rh.rhf.yqs.saas.gateway.biz.http.FileServletHandle;
import com.fingard.rh.rhf.yqs.saas.gateway.common.constant.GateWayCoreConstant;
import com.fingard.rh.rhf.yqs.saas.gateway.dto.FtpInfoDTO;
import com.fingard.rh.rhf.yqs.saas.gateway.dto.UrlHandleParam;
import com.fingard.rh.rhf.yqs.saas.gateway.util.CommonUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.net.ftp.FTPClient;
import org.apache.commons.net.ftp.FTPFile;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 文件导入处理类
 *
 * @author Ruvik
 * @create 2022/07/25 11:10
 */
@Service
@Slf4j
public class FileImportServletHandle extends FileServletHandle {

    @Override
    public boolean isSupport(UrlHandleParam urlHandleParam) {
        InterfaceBean interfaceBean = urlHandleParam.getInterfaceBean();
        return StrUtil.equals(interfaceBean.getIsFileInterface(), YesOrNoEnum.YES.getValue()) &&
                StrUtil.equals(interfaceBean.getFileInterfaceType(), FileInterFaceTypeEnum.UPLOAD.getValue()) &&
                StrUtil.equals(HttpRequestMethodEnum.POST.getValue(), interfaceBean.getRequestType());
    }

    @Override
    public void handleUrlReq(UrlHandleParam urlHandleParam) {
        log.info("收到文件上传请求");
        FtpInfoDTO ftpInfoDTO = getFTPInfo(cacheManager, CoreConstant.BR_FTP_CONFIG);
        List<String> remoteFilePathList = new ArrayList<>();
        try {
            // 获取文件上传对应的参数 "type":"{"key":"fileName","value":"type1"}" type对应一个json类型,还有其他一些前段需要的参数
            @SuppressWarnings("unchecked")
            Map<String, String> mapResult = (Map<String, String>) getParam(urlHandleParam);
            String fileTypeString = mapResult.get(GateWayCoreConstant.UPLOAD_FILE_VALUE_TYPE);
            mapResult.remove(GateWayCoreConstant.UPLOAD_FILE_VALUE_TYPE);
            if (StringUtils.isBlank(fileTypeString)) {
                fileTypeString = mapResult.get(GateWayCoreConstant.BATCH_UPLOAD_FILE_VALUE_TYPE);
                mapResult.remove(GateWayCoreConstant.BATCH_UPLOAD_FILE_VALUE_TYPE);
                if (StringUtils.isBlank(fileTypeString)) {
                    log.error("文件上传没有上传类型:[{}]", urlHandleParam.getHttpServletRequest().getServletPath());
                    writeResult(BaseReturnResult.getFailResult(), urlHandleParam.getHttpServletResponse());
                    return;
                }
                dealBatchUploadFile(urlHandleParam, fileTypeString, mapResult, ftpInfoDTO, remoteFilePathList);
                return;
            }
            dealUploadFile(urlHandleParam, fileTypeString, mapResult, ftpInfoDTO, remoteFilePathList);
        } finally {
            // 电商同步处理完文件后返回，或dubbo调用失败，删除不再需要的文件及其目录
            if (!CollectionUtils.isEmpty(remoteFilePathList)) {
                for (String remoteFilePath : remoteFilePathList) {
                    FtpUtil.deleteFile(ftpInfoDTO.getFtpClient(), remoteFilePath);
                    FtpUtil.removeDirectory(ftpInfoDTO.getFtpClient(), remoteFilePath.substring(0, remoteFilePath.lastIndexOf(GateWayCoreConstant.SLASH)));
                }
            }
            disconnectFtp(ftpInfoDTO.getFtpClient());
        }
    }

    private void dealUploadFile(UrlHandleParam urlHandleParam, String fileTypeString, Map<String, String> mapResult, FtpInfoDTO ftpInfoDTO, List<String> remoteFilePathList) {
        FileInfoBean fileInfoBean = JSON.parseObject(fileTypeString, FileInfoBean.class);
        MultipartHttpServletRequest mRequest = dealCheckFile(urlHandleParam);
        MultipartFile multipartFile = mRequest.getFile(GateWayCoreConstant.UPLOAD_FILE_PARAM);
        if(ObjectUtils.isEmpty(multipartFile)) {
            log.error("没有获取到请求中的上传文件:[{}]", urlHandleParam.getHttpServletRequest().getServletPath());
            writeResult(BaseReturnResult.getFailResult(), urlHandleParam.getHttpServletResponse());
            return;
        }
        String remotePath = GateWayCoreConstant.getFTPRandomFile(ftpPrefix, urlHandleParam.getUserInfo());
        remoteFilePathList.add(remotePath + GateWayCoreConstant.SLASH + multipartFile.getOriginalFilename());
        FileInfoBean infoBean = dealMultipartFile(remotePath, multipartFile, fileInfoBean, ftpInfoDTO);
        Map<String, Object> map = changeMapByFileInfo(mapResult, infoBean);
        callDubbo(urlHandleParam, zkUrl, map);
    }

    private void dealBatchUploadFile(UrlHandleParam urlHandleParam, String filesTypeString, Map<String, String> mapResult, FtpInfoDTO ftpInfoDTO, List<String> remoteFilePathList) {
        List<FileInfoBean> fileInfoBeanList = JSON.parseArray(filesTypeString, FileInfoBean.class);
        MultipartHttpServletRequest mRequest = dealCheckFile(urlHandleParam);
        List<MultipartFile> multipartFileList = mRequest.getFiles(GateWayCoreConstant.BATCH_UPLOAD_FILE_PARAM);
        if(CollectionUtils.isEmpty(multipartFileList)) {
            log.error("没有获取到请求中的上传文件:[{}]", urlHandleParam.getHttpServletRequest().getServletPath());
            writeResult(BaseReturnResult.getFailResult(), urlHandleParam.getHttpServletResponse());
            return;
        }
        List<FileInfoBean> listFileInfoBean = new ArrayList<>();
        for (int i = 0; i < fileInfoBeanList.size(); i++) {
            MultipartFile multipartFile = multipartFileList.get(i);
            FileInfoBean fileInfoBean = fileInfoBeanList.get(i);
            String remotePath = GateWayCoreConstant.getFTPRandomFile(ftpPrefix, urlHandleParam.getUserInfo());
            remoteFilePathList.add(remotePath + GateWayCoreConstant.SLASH + multipartFile.getOriginalFilename());
            FileInfoBean infoBean = dealMultipartFile(remotePath, multipartFile, fileInfoBean, ftpInfoDTO);
            listFileInfoBean.add(infoBean);
        }
        Map<String, Object> map = changeMapByFileInfoList(mapResult, listFileInfoBean);
        callDubbo(urlHandleParam, zkUrl, map);
    }

    private MultipartHttpServletRequest dealCheckFile(UrlHandleParam urlHandleParam) {
        MultipartHttpServletRequest mRequest = (MultipartHttpServletRequest) urlHandleParam.getHttpServletRequest();
        Map<String, MultipartFile> fileNames = CommonUtil.getFileNameKey(mRequest);
        checkFile(fileNames, urlHandleParam);
        return mRequest;
    }

    private FileInfoBean dealMultipartFile(String remotePath, MultipartFile multipartFile, FileInfoBean fileInfoBean, FtpInfoDTO ftpInfoDTO) {
        String filename = multipartFile.getOriginalFilename();
        //抛异常
        upload2FTP(ftpInfoDTO.getFtpClient(), multipartFile, remotePath, filename);
        fileInfoBean.setFileName(filename);
        fileInfoBean.setFilePath(remotePath);
        fileInfoBean.setFtpKey(ftpInfoDTO.getFtpConfigBean().getKey());
        return fileInfoBean;
    }

    @Override
    public void dealTheDubboResult(Object result, UrlHandleParam urlHandleParam) {
        try {
            writeResult(result, urlHandleParam.getHttpServletResponse());
        } catch (Exception e) {
            log.error("文件上传处理dubbo结果异常", e);
        }
    }

    private boolean checkFileType(InterfaceBean interfaceBean, Map<String, MultipartFile> fileNames) {
        if (ObjectUtils.isEmpty(interfaceBean.getFileCheckType())) {
            return false;
        }
        List<String> listFileName = new ArrayList<>();
        for (Map.Entry<String, MultipartFile> entries : fileNames.entrySet()) {
            listFileName.add(entries.getValue().getOriginalFilename());
        }
        // 校验数据
        return listFileName.stream().anyMatch(x -> {
            String suffix = x.substring(x.lastIndexOf("."));
            return !interfaceBean.getFileCheckType().contains(suffix);
        });
    }

    private boolean checkFileSize(InterfaceBean interfaceBean, Map<String, MultipartFile> fileNames) {
        if (ObjectUtils.isEmpty(interfaceBean.getFileSize())) {
            return false;
        }
        // 这里的单位是b
        List<Long> listFileSize = new ArrayList<>();
        for (Map.Entry<String, MultipartFile> entries : fileNames.entrySet()) {
            listFileSize.add(entries.getValue().getSize());
        }
        //转换到b
        long bitSize = interfaceBean.getFileSize() * 1024;
        // 校验数据
        return listFileSize.stream().anyMatch(x -> x > bitSize);
    }

    private Map<String, Object> changeMapByFileInfo(Map<String, String> map, FileInfoBean fileInfoBean) {
        Map<String, Object> objectMap = new HashMap<>(map);
        objectMap.put(GateWayCoreConstant.UPLOAD_FILE_VALUE_TYPE, fileInfoBean);
        return objectMap;
    }

    private Map<String, Object> changeMapByFileInfoList(Map<String, String> map, List<FileInfoBean> fileInfoBeanList) {
        Map<String, Object> objectMap = new HashMap<>(map);
        objectMap.put(GateWayCoreConstant.BATCH_UPLOAD_FILE_VALUE_TYPE, fileInfoBeanList);
        return objectMap;
    }

    private void checkFile(Map<String, MultipartFile> fileNames, UrlHandleParam urlHandleParam) {
        if (fileNames.isEmpty()) {
            log.error("文件上传出现异常，无法找到文件名:[{}]", urlHandleParam.getHttpServletRequest().getServletPath());
            throw new RuntimeException();
        }
        if (checkFileType(urlHandleParam.getInterfaceBean(), fileNames)) {
            log.error("文件校验失败:[{}],类型异常", urlHandleParam.getHttpServletRequest().getServletPath());
            throw new RuntimeException();
        }
        if (checkFileSize(urlHandleParam.getInterfaceBean(), fileNames)) {
            log.error("文件校验失败:[{}],文件大小异常", urlHandleParam.getHttpServletRequest().getServletPath());
            throw new RuntimeException();
        }
    }

    private void upload2FTP(FTPClient ftpClient, MultipartFile multipartFile, String remotePath, String fileName) {
        log.info("准备上传文件,文件名[{}]", fileName);
        try (InputStream inputStream = multipartFile.getInputStream()) {
            if (!FtpUtil.upload(ftpClient, inputStream, remotePath, fileName)) {
                log.error("上传文件失败,文件名[{}]，远程地址[{}]", fileName, remotePath);
            }
            log.info("上传文件成功,文件名[{}]，远程地址[{}]", fileName, remotePath);
        } catch (IOException e) {
            log.error("文件上传ftp出现异常", e);
            throw new RuntimeException();
        }
    }

    private void deleteDirectory(FTPClient ftpClient, String remotePath) {
        try {
            FTPFile[] ftpFiles = ftpClient.listFiles(remotePath);
            if (ObjectUtils.isNotEmpty(ftpFiles)) {
                for (FTPFile file : ftpFiles) {
                    if (file.isDirectory()) {
                        deleteDirectory(ftpClient, remotePath + GateWayCoreConstant.SLASH + file.getName());
                    }
                }
            }
            FtpUtil.removeDirectory(ftpClient, remotePath);
        } catch (Exception e) {
            log.error("删除文件夹出现异常", e);
        }
    }

}
