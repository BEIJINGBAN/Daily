package com.fingard.rh.rhf.yqs.saas.gateway.common.enums;

import com.fingard.rh.rhf.yqs.saas.common.enums.LabelAndValue;

/**
 * @author Ruvik
 * @create 2022/09/20 8:16
 */
public enum AuthEnum implements LabelAndValue<String> {

    NO_AUTH("3", "完全不需要认证"),

    TOKEN_AUTH("0", "token认证"),
    SHOULD_AUTH("1", "需要认证"),
    REGULAR_AUTH("2", "固定token认证");

    private final String value;
    private final String label;

    AuthEnum(String value, String label) {
        this.value = value;
        this.label = label;
    }

    @Override
    public String getValue() {
        return value;
    }

    @Override
    public String getLabel() {
        return label;
    }
}
