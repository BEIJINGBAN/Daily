package com.fingard.rh.rhf.yqs.saas.gateway.exception;

import lombok.Getter;

/**
 * 企业特殊错误
 *
 * @author Ruvik
 * @create 2023/08/07 19:36
 */
public class EnterpriseException extends RuntimeException {
    @Getter
    private String returnMsg;

    @Getter
    private Throwable throwable;

    public EnterpriseException(String returnMsg, Throwable throwable) {
        super(returnMsg, throwable);
        this.returnMsg = returnMsg;
        this.throwable = throwable;
    }
}
