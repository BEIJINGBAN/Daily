package com.fingard.rh.rhf.yqs.saas.gateway.util;

import cn.hutool.core.util.ObjectUtil;
import cn.hutool.core.util.StrUtil;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.TypeReference;
import com.fingard.rh.rhf.yqs.saas.common.beans.BaseReturnResult;
import com.fingard.rh.rhf.yqs.saas.common.beans.cache.LocalCache;
import com.fingard.rh.rhf.yqs.saas.common.beans.constant.RedisConstant;
import com.fingard.rh.rhf.yqs.saas.common.beans.domain.DoMainConfig;
import com.fingard.rh.rhf.yqs.saas.common.beans.file.FileInfoBean;
import com.fingard.rh.rhf.yqs.saas.common.beans.gateway.InterfaceBean;
import com.fingard.rh.rhf.yqs.saas.common.beans.user.LogRecord;
import com.fingard.rh.rhf.yqs.saas.common.beans.user.UserContext;
import com.fingard.rh.rhf.yqs.saas.common.beans.user.UserInfo;
import com.fingard.rh.rhf.yqs.saas.gateway.common.constant.GateWayCoreConstant;
import com.fingard.rh.rhf.yqs.saas.gateway.conf.GateWayDubboKeyGenerator;
import com.fingard.rh.rhf.yqs.saas.gateway.dto.UniversalDTO;
import lombok.extern.slf4j.Slf4j;
import org.apache.dubbo.config.ApplicationConfig;
import org.apache.dubbo.config.ReferenceConfig;
import org.apache.dubbo.config.RegistryConfig;
import org.apache.dubbo.config.utils.ReferenceConfigCache;
import org.apache.dubbo.rpc.RpcContext;
import org.apache.dubbo.rpc.service.GenericService;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import java.util.*;

/**
 * @author Ruvik
 * @create 2022/07/25 17:55
 */
@Slf4j
public class CommonUtil {

    public static Map<String, MultipartFile> getFileNameKey(MultipartHttpServletRequest httpServletRequest) {
        Map<String, MultipartFile> multipartFile = new HashMap<>();
        Iterator<String> iterator = httpServletRequest.getFileNames();
        while (iterator.hasNext()) {
            String fileNameKey = iterator.next();
            if (StrUtil.isNotEmpty(fileNameKey)) {
                multipartFile.put(fileNameKey, httpServletRequest.getFile(fileNameKey));
            }
        }
        return multipartFile;
    }

    public static Object getFirstValue(JSONObject jsonObject) {
        for (Map.Entry<String, Object> entry : jsonObject.entrySet()) {
            return entry.getValue();
        }
        return null;
    }

    public static String getPictureUrl(FileInfoBean ftpInfoDTO, DoMainConfig doMainConfig) {
        String ftpUrl;
        if ("/".equals(doMainConfig.getFtpPrefix())) {
            ftpUrl = doMainConfig.getNginxPrefix() + "/" + ftpInfoDTO.getFilePath();
        } else {
            ftpUrl = ftpInfoDTO.getFilePath().replace(doMainConfig.getFtpPrefix(), doMainConfig.getNginxPrefix());
        }
        return doMainConfig.getDomain() + ftpUrl;
    }


    /**
     * 判断当前url是不是符合通配符
     * 例：请求url为 /webx/abc/update，key为 /webx/abc/**，则符合通配，返回true
     *
     * @return
     */
    public static UniversalDTO judgeUniversal(String urlPath, LocalCache localCache) {
        Set<Map.Entry<String, Object>> entries = localCache.getEntrySet();
        for (Map.Entry<String, Object> entry : entries) {
            String cacheKey = entry.getKey();
            if (cacheKey.contains("*")) {
                String key = cacheKey.replace(RedisConstant.YQS_GATEWAY_CACHE + ":", "").replaceAll("/\\*\\*", "");
                if (urlPath.contains(key)) {
                    return UniversalDTO.builder().exist(true).key(cacheKey).build();
                }
            }
        }
        return UniversalDTO.builder().exist(false).build();
    }

    /**
     * 生成泛化方法 如果一直new 会oom(压测结果) 因此需要使用缓存
     *
     * @param interfaceBean
     * @param zkUrl
     * @return
     */
    public static Object generic(InterfaceBean interfaceBean, String zkUrl,
                                 String[] strings, Object[] objects, String providerAddress, UserInfo userInfo) {
        setUserInfo(userInfo);
        UserContext.clearRemark();
        setLogRecord(objects);

        ReferenceConfig<GenericService> referenceConfig = new ReferenceConfig<>();
        referenceConfig.setApplication(new ApplicationConfig("gateway"));
        referenceConfig.setRegistry(new RegistryConfig(zkUrl));
        // 禁止重试
        referenceConfig.setRetries(0);
        referenceConfig.setInterface(StrUtil.isEmpty(interfaceBean.getInterfaceName()) ? null : interfaceBean.getInterfaceName());
        referenceConfig.setVersion(StrUtil.isEmpty(interfaceBean.getVersion()) ? null : interfaceBean.getVersion());
        referenceConfig.setGroup(StrUtil.isEmpty(interfaceBean.getGroup()) ? null : interfaceBean.getGroup());
        referenceConfig.setGeneric(true);
        referenceConfig.setTimeout(ObjectUtil.isNull(interfaceBean.getTimeOut()) ? 4000 : interfaceBean.getTimeOut());
        // 加了指定ip并且不是校验权限的接口
        if (StrUtil.isNotEmpty(providerAddress) && !interfaceBean.getMethod().contains(GateWayCoreConstant.CHECK_USER_PERMISSION)) {
            referenceConfig.setUrl("dubbo://" + providerAddress);
        }
        GenericService genericService;
        // 不需要走定向的则从缓存中获取
        if (StrUtil.isEmpty(referenceConfig.getUrl())) {
            ReferenceConfigCache referenceCache = ReferenceConfigCache.getCache("DEFAULE_NAME", new GateWayDubboKeyGenerator());
            genericService = referenceCache.get(referenceConfig);
        } else {
            // 需要定向不在走缓存，oom也无所谓
            genericService = referenceConfig.get();
        }
        log.info("泛化调用参数:[{}],[{}]", Arrays.asList(strings), JSON.toJSONString(Arrays.asList(objects)));
        Object result = genericService.$invoke(interfaceBean.getMethod(), strings, objects);
        log.info("泛化返回结果:[{}]", result);
        return result;
    }

    public static <T> BaseReturnResult<T> genResult(Object result, Class<T> tClass) {
        String json = JSONObject.toJSONString(result);
        return JSON.parseObject(json, new TypeReference<BaseReturnResult<T>>(tClass) {
        });
    }

    public static void setUserInfo(UserInfo userInfo) {
        if (ObjectUtil.isNotNull(userInfo)) {
            RpcContext.getContext().setAttachment(UserContext.RPC_CONTENT_KEY, JSON.toJSONString(userInfo));
        }
    }

    public static void setLogRecord(Object[] objects) {
        //根据objects中是否包含logRecord来判断是否是操作日志请求参数处理
        if (objects != null && objects.length > 0 && String.valueOf(objects[0]).contains("logRecord")) {
            Object object = objects[0];
            Map<String, Object> mapType = JSON.parseObject(String.valueOf(object), new TypeReference<Map<String, Object>>() {
            });
            if (mapType.containsKey("logRecord")) {
                Map<String, String> remark = JSON.parseObject(String.valueOf(mapType.get("logRecord")), new TypeReference<Map<String, String>>() {
                });
                if (ObjectUtil.isNotNull(remark.get("remark"))) {
                    LogRecord test = new LogRecord();
                    test.setRemark(remark.get("remark"));
                    RpcContext.getContext().setAttachment(UserContext.RPC_LOG_RECORD_KEY, JSON.toJSONString(test));
                }
            }
        }

    }

    public static void main(String[] args) {
        ReferenceConfig<GenericService> referenceConfig = new ReferenceConfig<>();
        referenceConfig.setApplication(new ApplicationConfig("gateway"));
        referenceConfig.setRegistry(new RegistryConfig("zookeeper://10.60.45.191:2181?timeout=10000"));
        // 禁止重试
        referenceConfig.setRetries(0);
        referenceConfig.setInterface("com.fingard.rh.rhf.microservice.ucs.api.UniqueControlApi");
        referenceConfig.setTimeout(10000);
        referenceConfig.setGeneric(true);
        GenericService genericService = referenceConfig.get();
        Map<String, Object> map = new HashMap<>();
        map.put("enterpriseNum", "QT330001");
        map.put("bankCode", "Z310");
        map.put("productId", "1");
        map.put("nodeId", "1");
        Object result = genericService.$invoke("getUniqueBillNo", new String[]{"com.fingard.rh.rhf.microservice.ucs.api.UniqueControlReq"}, new Object[]{map});
        System.out.println(result);

    }

}
