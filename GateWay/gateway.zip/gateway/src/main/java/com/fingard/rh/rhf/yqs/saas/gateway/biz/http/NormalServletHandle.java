package com.fingard.rh.rhf.yqs.saas.gateway.biz.http;

import cn.hutool.core.util.ObjectUtil;
import cn.hutool.core.util.StrUtil;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.fingard.rh.rhf.yqs.saas.common.beans.constant.CoreConstant;
import com.fingard.rh.rhf.yqs.saas.common.beans.constant.RedisConstant;
import com.fingard.rh.rhf.yqs.saas.common.beans.gateway.InterfaceBean;
import com.fingard.rh.rhf.yqs.saas.common.beans.gateway.MerchantTenantCacheDTO;
import com.fingard.rh.rhf.yqs.saas.common.beans.gateway.TenantRegistryCacheDTO;
import com.fingard.rh.rhf.yqs.saas.common.beans.user.UserInfo;
import com.fingard.rh.rhf.yqs.saas.common.enums.GateWayParamTypeEnum;
import com.fingard.rh.rhf.yqs.saas.gateway.common.constant.GateWayCoreConstant;
import com.fingard.rh.rhf.yqs.saas.gateway.dto.UrlHandleParam;
import com.fingard.rh.rhf.yqs.saas.gateway.manager.CacheManager;
import com.fingard.rh.rhf.yqs.saas.gateway.util.CommonUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.dubbo.rpc.RpcContext;

import javax.servlet.ServletInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author Ruvik
 * @create 2023/02/18 15:23
 */
@Slf4j
public abstract class NormalServletHandle implements ServletHandle {

    public Object getJsonParam(UrlHandleParam urlHandleParam) {
        //从前端获取输入字节流
        InterfaceBean interfaceBean = urlHandleParam.getInterfaceBean();
        //开始拼装json字符串
        String value = getContentFromStream(urlHandleParam);
        // 如果是json的直接返回字符串,同时string也是java.lang.String
        if (GateWayParamTypeEnum.JSON_PARAM.getValue().equals(interfaceBean.getParamType()) || GateWayParamTypeEnum.XML_PARAM.getValue().equals(interfaceBean.getParamType())) {
            return value;
        }
        JSONObject jsonObject = JSONObject.parseObject(value);
        if ((StrUtil.isNotEmpty(interfaceBean.getParamType()) &&
                interfaceBean.getParamType().contains(GateWayParamTypeEnum.BEAN_PARAM.getValue())) ||
                StrUtil.equals(GateWayParamTypeEnum.MAP_PARAM.getValue(), interfaceBean.getParamType()) ||
                StrUtil.equals(GateWayParamTypeEnum.JSON_PARAM.getValue(), interfaceBean.getParamType())) {
            return jsonObject;
        } else if (StrUtil.equals(GateWayParamTypeEnum.STRING_PARAM.getValue(), interfaceBean.getParamType()) ||
                StrUtil.equals(GateWayParamTypeEnum.LIST_PARAM.getValue(), interfaceBean.getParamType()) ||
                StrUtil.equals(GateWayParamTypeEnum.INTEGER_PARAM.getValue(), interfaceBean.getParamType()) ||
                StrUtil.equals(GateWayParamTypeEnum.LONG_PARAM.getValue(), interfaceBean.getParamType())) {
            return CommonUtil.getFirstValue(jsonObject);
        }
        return null;
    }

    public String getContentFromStream(UrlHandleParam urlHandleParam) {
        try (ServletInputStream requestInputStream = urlHandleParam.getHttpServletRequest().getInputStream()) {
            StringBuilder sb = new StringBuilder();
            int total = 0;
            //将字节流转换为字符流,并设置字符编码为utf-8
            //使用字符缓冲流进行读取
            try (InputStreamReader ir = new InputStreamReader(requestInputStream, StandardCharsets.UTF_8);
                 BufferedReader br = new BufferedReader(ir)) {
                String line;
                while ((line = br.readLine()) != null) {
                    total += 1;
                    sb.append(line);
                }
                log.info("读取的数据长度:[{}]", total);
            } catch (IOException e) {
                log.error("获取json数据出现异常", e);
                throw new RuntimeException("获取json数据出现异常");
            }
            return sb.toString();
        } catch (IOException ex) {
            log.error("获取输入流数据出现异常", ex);
            throw new RuntimeException("获取输入流数据出现异常");
        }
    }

    /**
     * 额外添加参数 不能出现异常
     *
     * @param urlHandleParam
     */
    public void setParam(UrlHandleParam urlHandleParam) {
        try {
            Map<String, List<String>> mapParam = new HashMap<>();
            for (Map.Entry<String, String[]> stringSet : urlHandleParam.getHttpServletRequest().getParameterMap().entrySet()) {
                mapParam.put(stringSet.getKey(), Arrays.asList(stringSet.getValue()));
            }
            RpcContext.getContext().setAttachment(CoreConstant.URL_PARAM, urlHandleParam.getHttpServletRequest().getServletPath());
            RpcContext.getContext().setAttachment(CoreConstant.PARAM_MAP, mapParam);
        } catch (Exception e) {
            log.error("添加参数异常", e);
        }
    }

    /**
     * 获取url接口
     *
     * @param zkUrl
     * @param mchId
     * @return
     */
    public String getZkAddress(String zkUrl, String mchId, UrlHandleParam urlHandleParam, CacheManager cacheManager) {
        try {
            InterfaceBean interfaceBean = urlHandleParam.getInterfaceBean();
            if (StrUtil.isNotBlank(mchId)) {
                MerchantTenantCacheDTO merchantTenantCacheDTO = cacheManager.getCache(RedisConstant.YQS_GATEWAY_MERCHANT_TENANT);
                if (ObjectUtil.isNull(merchantTenantCacheDTO)) {
//                    log.error("无法获取到商户号企业缓存:[{}],[{}],[{}]", interfaceBean, mchId, merchantTenantCacheDTO);
                    return zkUrl;
                }
                MerchantTenantCacheDTO.MerchantTenantCacheEntity merchantTenantCacheEntity = merchantTenantCacheDTO.get(mchId);
                if (ObjectUtil.isNull(merchantTenantCacheEntity) || StrUtil.isEmpty(merchantTenantCacheEntity.getTenantCode())) {
//                    log.error("无法获取到商户号企业配置:[{}],[{}],[{}]", interfaceBean, mchId, merchantTenantCacheDTO);
                    return zkUrl;
                }
                String tenantCode = merchantTenantCacheEntity.getTenantCode();
                return getZkAddressByTenantCode(cacheManager, tenantCode, mchId, interfaceBean, zkUrl);
            } else {
                UserInfo userInfo = urlHandleParam.getUserInfo();
                if (ObjectUtil.isNull(userInfo) || StrUtil.isEmpty(userInfo.getSwitchTenantCode())) {
//                    log.error("根据用户切换组织异常:[{}]", userInfo);
                    return zkUrl;
                }
                return getZkAddressByTenantCode(cacheManager, userInfo.getSwitchTenantCode(), mchId, interfaceBean, zkUrl);
            }
        } catch (Exception e) {
            log.error("获取不同企业zk地址异常", e);
        }
        return zkUrl;
    }

    private String getZkAddressByTenantCode(CacheManager cacheManager, String tenantCode, String mchId, InterfaceBean interfaceBean, String zkUrl) {
        TenantRegistryCacheDTO tenantRegistryCacheDTO = cacheManager.getCache(RedisConstant.tenantRegistryAddressKey(tenantCode));
        if (ObjectUtil.isNull(tenantRegistryCacheDTO)) {
//            log.error("无法获取到企业zk地址缓存:[{}],[{}],[{}]", interfaceBean, mchId, tenantRegistryCacheDTO);
            return zkUrl;
        }
        TenantRegistryCacheDTO.TenantRegistryCacheEntity tenantRegistryCacheEntity = tenantRegistryCacheDTO.get(interfaceBean.getServiceName());
        if (ObjectUtil.isNull(tenantRegistryCacheEntity) || StrUtil.isEmpty(tenantRegistryCacheEntity.getRegistryAddress())) {
            log.error("获取到企业zk地址缓存数据异常:[{}],[{}],[{}]", interfaceBean, mchId, tenantRegistryCacheDTO);
            return zkUrl;
        }
        return tenantRegistryCacheEntity.getRegistryAddress();
    }

    protected String getMchId(Object getJsonParamResult){
        JSONObject jsonObject;
        if(ObjectUtil.isNull(getJsonParamResult)){
            return StrUtil.EMPTY;
        } else if (getJsonParamResult instanceof JSONObject){
            jsonObject = (JSONObject)getJsonParamResult;
        } else if(getJsonParamResult instanceof String){
            String result = (String)getJsonParamResult;
            jsonObject = JSON.parseObject(result);
        }else{
            jsonObject = JSON.parseObject(JSON.toJSONString(getJsonParamResult));
        }

        return jsonObject.getString(GateWayCoreConstant.MCH_ID);
    }
}
