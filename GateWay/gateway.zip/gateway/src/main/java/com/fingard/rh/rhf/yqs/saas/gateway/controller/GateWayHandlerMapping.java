package com.fingard.rh.rhf.yqs.saas.gateway.controller;

import com.fingard.rh.rhf.yqs.saas.common.beans.cache.LocalCache;
import com.fingard.rh.rhf.yqs.saas.common.beans.constant.RedisConstant;
import com.fingard.rh.rhf.yqs.saas.gateway.manager.CacheManager;
import com.fingard.rh.rhf.yqs.saas.gateway.util.CommonUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.servlet.HandlerExecutionChain;
import org.springframework.web.servlet.handler.AbstractUrlHandlerMapping;

import javax.servlet.http.HttpServletRequest;

/**
 * @author Ruvik
 * @create 2022/07/20 15:17
 */
@Slf4j
@Component
public class GateWayHandlerMapping extends AbstractUrlHandlerMapping {

    private final GateWayController gateWayController;
    private final CacheManager cacheManager;

    public GateWayHandlerMapping(GateWayController gateWayController, CacheManager cacheManager) {
        this.gateWayController = gateWayController;
        this.cacheManager = cacheManager;
        setOrder(-200);
    }

    @Override
    protected HandlerExecutionChain getCorsHandlerExecutionChain(HttpServletRequest request,
                                                                 HandlerExecutionChain chain, CorsConfiguration config) {
        if (config == null) {
            // Allow CORS requests to go to the backend
            return chain;
        }
        return super.getCorsHandlerExecutionChain(request, chain, config);
    }

    @Override
    protected Object lookupHandler(String urlPath, HttpServletRequest request) throws Exception {
        LocalCache localCache = cacheManager.getLocalCache();
        // 只有注册的url才能注册，否则返回404
        if (localCache.containsCacheKey(RedisConstant.urlKey(urlPath)) ||
                CommonUtil.judgeUniversal(urlPath, localCache).isExist()) {
            synchronized (this) {
                registerHandlers(urlPath);
            }
            return super.lookupHandler(urlPath, request);
        } else {
            log.warn("未能匹配对应url");
            return null;
        }
    }


    private void registerHandlers(String urlPath) {
        registerHandler(urlPath, this.gateWayController);
    }
}
