package com.fingard.rh.rhf.yqs.saas.gateway.biz.http.impl;

import cn.hutool.core.util.StrUtil;
import com.fingard.rh.rhf.yqs.saas.common.beans.gateway.InterfaceBean;
import com.fingard.rh.rhf.yqs.saas.common.enums.HttpRequestMethodEnum;
import com.fingard.rh.rhf.yqs.saas.common.enums.YesOrNoEnum;
import com.fingard.rh.rhf.yqs.saas.gateway.biz.http.NormalServletHandle;
import com.fingard.rh.rhf.yqs.saas.gateway.dto.UrlHandleParam;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;

/**
 * form表单处理类
 *
 * @author Ruvik
 * @create 2022/07/25 10:34
 */
@Service
@Slf4j
public class FormServletHandle extends NormalServletHandle {

    @Value("${dubbo.registry.address}")
    private String zkUrl;

    @Override
    public boolean isSupport(UrlHandleParam urlHandleParam) {
        InterfaceBean interfaceBean = urlHandleParam.getInterfaceBean();
        return StrUtil.equals(interfaceBean.getIsFileInterface(), YesOrNoEnum.NO.getValue()) &&
                StrUtil.equals(HttpRequestMethodEnum.POST.getValue(), interfaceBean.getRequestType()) &&
                (StrUtil.equals(interfaceBean.getContentType(), MediaType.APPLICATION_FORM_URLENCODED_VALUE) || StrUtil.equals(interfaceBean.getContentType(), MediaType.MULTIPART_FORM_DATA_VALUE));
    }

    @Override
    public void handleUrlReq(UrlHandleParam urlHandleParam) {
        callDubbo(urlHandleParam, zkUrl, getParam(urlHandleParam));
    }

    @Override
    public void dealTheDubboResult(Object result, UrlHandleParam urlHandleParam)  {
        writeResult(result, urlHandleParam.getHttpServletResponse());
    }
}
