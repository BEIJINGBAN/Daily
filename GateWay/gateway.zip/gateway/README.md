# gateway

网关
Sentinel控制台部署：
http://10.60.45.244/project-51/doc-2100/

Sentinel控制台使用手册：
http://10.60.45.244/project-51/doc-699/

## saas-1.2.0版本配置文件变动：
新增：
```properties
#####################################################################
# Sentinel相关配置
#####################################################################
# 指定控制台的地址和端口，若不配置此项，sentinel将停用
csp.sentinel.dashboard.server=10.60.45.192:8780
# 指定当前应用 将使用哪个端口与控制台通信
csp.sentinel.api.port=8721
# Sentinel 日志文件目录 默认${user.home}/logs/csp/
csp.sentinel.log.dir=
# 用于在sentinel控制台展示应用名称，不填默认 yqs-saas-gateway
csp.sentinel.project.name=yqs-saas-gateway-local
```