package com.fingard.rh.rhf.yqs.saas.gateway.exception;

import lombok.Getter;

/**
 * @author Don
 * @date 2022/11/9.
 */
public class GatewayException extends RuntimeException {

    @Getter
    private String returnMsg;

    public GatewayException(String returnMsg) {
        this.returnMsg = returnMsg;
    }
}
