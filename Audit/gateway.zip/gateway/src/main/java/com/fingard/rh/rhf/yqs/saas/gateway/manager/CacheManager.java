package com.fingard.rh.rhf.yqs.saas.gateway.manager;

import com.alibaba.fastjson.JSON;
import com.fingard.rh.rhf.yqs.saas.common.beans.cache.LocalCache;
import com.fingard.rh.rhf.yqs.saas.common.beans.constant.RedisConstant;
import com.fingard.rh.rhf.yqs.saas.common.beans.message.Message;
import com.fingard.rh.rhf.yqs.saas.common.enums.MessageEnum;
import com.fingard.rh.rhf.yqs.saas.gateway.biz.http.PushMessageService;
import com.fingard.rh.rhf.yqs.saas.gateway.common.constant.GateWayCoreConstant;
import lombok.extern.slf4j.Slf4j;
import org.redisson.api.RBucket;
import org.redisson.api.RTopic;
import org.redisson.api.RedissonClient;
import org.springframework.stereotype.Component;

import java.util.Iterator;
import java.util.concurrent.locks.ReentrantLock;

/**
 * @author Ruvik
 * @create 2022/09/21 10:41
 */
@Component
@Slf4j
public class CacheManager {

    private final LocalCache localCache = new LocalCache();

    private final PushMessageService pushMessageService;

    private static final ReentrantLock reentrantLock = new ReentrantLock();

    private final RedissonClient redissonClient;

    public CacheManager(PushMessageService pushMessageService, RedissonClient redissonClient) {
        this.pushMessageService = pushMessageService;
        this.redissonClient = redissonClient;
    }

    public <T> T getCache(String key) {
        if (cacheBucketExist(key)) {
            RBucket<T> rBucket = redissonClient.getBucket(key);
            return rBucket.get();
        }
        return null;
    }

    public boolean cacheBucketExist(String key) {
        return redissonClient.getBucket(key).isExists();
    }

    public void refreshCache() {
        // 定时任务和初始化都有可能走这个逻辑，因此两个并发的时候只需要走一个可以了。
        try {
            if (reentrantLock.tryLock()) {
                // 初始化刷新接口
                localCache.setCache(RedisConstant.urlKey(GateWayCoreConstant.REFRESH_CACHE_URL), "");
                Iterator<String> iterator = redissonClient.getKeys().getKeysByPattern(RedisConstant.YQS_GATEWAY_CACHE + "*").iterator();
                while (iterator.hasNext()) {
                    String key = iterator.next();
                    if (redissonClient.getBucket(key).isExists()) {
                        localCache.setCache(key, redissonClient.getBucket(key).get());
                    }
                }
            } else {
                log.error("网关刷新缓存没有获取到锁");
            }
        } catch (Exception e) {
            log.error("缓存初始化出现异常", e);
        } finally {
            reentrantLock.unlock();
        }
    }

    public void addListener() {
        RTopic topic = redissonClient.getTopic(RedisConstant.YQS_BASE_MESSAGE);
        topic.addListener(Message.class, (charSequence, mag) -> {
            pushMessageService.sendMsg(mag.getUserId(), JSON.toJSONString(mag));
            log.info("Redisson监听器收到发送给用户[{}]消息:{}", mag.getUserId(), mag.getContent());
        });
    }

    public void addRepeatLoginListener() {
        RTopic topic = redissonClient.getTopic(RedisConstant.YQS_BASE_REPEAT_LOGIN_MESSAGE);
        topic.addListener(Message.class, (charSequence, mag) -> {
            log.info("用户[{}]登录时token已存在,通知websocket发送消息", mag.getUserId());
            pushMessageService.sendMsg(mag.getUserId(), JSON.toJSONString(new Message<>(mag.getUserId(), MessageEnum.BASE_REPEAT_LOGIN.getValue(), "该账号已在别处登录，您将退出系统。", null)));
        });
    }

    public LocalCache getLocalCache() {
        return localCache;
    }
}
