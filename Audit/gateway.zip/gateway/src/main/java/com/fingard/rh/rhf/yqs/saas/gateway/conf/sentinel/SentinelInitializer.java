package com.fingard.rh.rhf.yqs.saas.gateway.conf.sentinel;

import cn.hutool.core.thread.ThreadUtil;
import com.alibaba.csp.sentinel.adapter.servlet.callback.WebCallbackManager;
import com.alibaba.csp.sentinel.config.SentinelConfig;
import com.alibaba.csp.sentinel.heartbeat.HeartbeatSenderProvider;
import com.alibaba.csp.sentinel.init.InitExecutor;
import com.alibaba.csp.sentinel.log.LogBase;
import com.alibaba.csp.sentinel.slots.block.degrade.DegradeRuleManager;
import com.alibaba.csp.sentinel.slots.block.flow.FlowRuleManager;
import com.alibaba.csp.sentinel.slots.system.SystemRuleManager;
import com.alibaba.csp.sentinel.transport.HeartbeatSender;
import com.alibaba.csp.sentinel.transport.config.TransportConfig;
import com.alibaba.fastjson.JSON;
import com.fingard.rh.rhf.yqs.saas.common.beans.BaseReturnResult;
import com.fingard.rh.rhf.yqs.saas.common.interfaces.init.Initializer;
import com.fingard.rh.rhf.yqs.saas.gateway.util.IOUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * @author tianzh
 * @date 2022/10/18
 */
@Slf4j
@Component
public class SentinelInitializer implements Initializer {

    @Value("${csp.sentinel.log.dir}")
    private String logDir;

    @Value("${csp.sentinel.dashboard.server}")
    private String consoleServer;

    @Value("${csp.sentinel.api.port}")
    private String serverPort;

    @Value("${csp.sentinel.project.name:yqs-saas-gateway}")
    private String projectName;

    private static final String DEFAULT_PROJECT_NAME = "yqs-saas-gateway";

    @Override
    public void init() {
        log.info("正在初始化sentinel......");
        if (StringUtils.isBlank(consoleServer)) {
            log.error("Sentinel控制台的IP和端口未配置(例: 127.0.0.1:8780)，系统将停用sentinel功能。");
            return;
        }
        this.sentinelInit();
        log.info("sentinel初始化完成");
        log.info("当前限流规则：{}", FlowRuleManager.getRules());
        log.info("当前熔断规则：{}", DegradeRuleManager.getRules());
        log.info("当前系统保护规则：{}", SystemRuleManager.getRules());
    }

    private void sentinelInit() {
        // sentinel首先会去[sentinel.properties]加载配置，其次 会把System.getProperties()的配置也加载进来 覆盖已存在的配置
        // 我们这边没有添加sentinel.properties文件
        // 设置参数
        if (StringUtils.isBlank(consoleServer)) {
            log.error("Sentinel控制台的IP和端口未配置(例: 127.0.0.1:8780)，系统将停用sentinel功能。");
            return;
        }
        // 控制台的IP和端口必填
        System.setProperty(TransportConfig.CONSOLE_SERVER, consoleServer);

        // 指定当前应用 将使用哪个端口与控制台通信。 可不填，不填则 8720~随机端口
        if (StringUtils.isNotBlank(serverPort)) {
            System.setProperty(TransportConfig.SERVER_PORT, serverPort);
        }

        // 指定当前应用的应用名，若未指定，则默认解析 main 函数的类名作为应用名。

        if (StringUtils.isBlank(projectName)) {
            projectName = DEFAULT_PROJECT_NAME;
        }
        System.setProperty(SentinelConfig.PROJECT_NAME_PROP_KEY, projectName);

        if (StringUtils.isNotBlank(logDir)) {
            System.setProperty(LogBase.LOG_DIR, logDir);
        }

        // 触发Sentinel的初始化，这里会自动每隔10s发送一次心跳给控制台，发送失败时会记录到csp.sentinel.log.dir日志中
        InitExecutor.doInit();

        // 手动发送一次心跳，查看控制台是否能正常接收，以此判定控制台是否正常
        // 睡眠一秒，因为发送心跳之前需要等待CommandCenter初始化(异步的)完成
        ThreadUtil.sleep(1000);
        this.checkDashboard();

        // 设置限流时 返回的信息
        WebCallbackManager.setUrlBlockHandler((request, response, ex) -> {
            log.warn("请求url：[" + request.getServletPath() + "] 被Sentinel拒绝。", ex);
            BaseReturnResult<String> result = BaseReturnResult.getFailResult("操作过于频繁，请稍后再试！");
            IOUtil.writeResult(JSON.toJSONString(result), response);
        });
    }

    private void checkDashboard() {
        try {
            HeartbeatSender sender = HeartbeatSenderProvider.getHeartbeatSender();
            if (sender == null) {
                log.warn("HeartbeatSender加载失败，请检查[com.alibaba.csp.sentinel.transport.HeartbeatSender]的SPI配置是否存在");
                return;
            }
            boolean sendSuccess = sender.sendHeartbeat();
            if (!sendSuccess) {
                log.error("心跳发送失败，请检查控制台对应的ip端口：" + consoleServer);
            }
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}
