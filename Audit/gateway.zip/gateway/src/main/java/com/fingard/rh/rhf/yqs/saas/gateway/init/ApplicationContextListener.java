package com.fingard.rh.rhf.yqs.saas.gateway.init;

import com.fingard.rh.rhf.yqs.saas.common.interfaces.init.Initializer;
import com.fingard.rh.rhf.yqs.saas.common.util.InitExecutor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.ApplicationListener;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * @author lincc
 * @version 1.0 2021/7/16
 * 启动监听类
 */
@Slf4j
@Component
public class ApplicationContextListener implements ApplicationListener<ApplicationReadyEvent> {

    @Autowired
    private List<Initializer> initializerList;

    @Override
    public void onApplicationEvent(ApplicationReadyEvent event) {
        InitExecutor.doInit(initializerList);
    }
}
