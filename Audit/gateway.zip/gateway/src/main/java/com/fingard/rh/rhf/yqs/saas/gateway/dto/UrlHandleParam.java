package com.fingard.rh.rhf.yqs.saas.gateway.dto;

import com.fingard.rh.rhf.yqs.saas.common.beans.gateway.InterfaceBean;
import com.fingard.rh.rhf.yqs.saas.common.beans.user.UserInfo;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.Serializable;

/**
 * 封装url处理参数类
 *
 * @author Ruvik
 * @create 2022/08/08 13:25
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class UrlHandleParam implements Serializable {

    private static final long serialVersionUID = -703276343545487902L;

    private HttpServletRequest httpServletRequest;

    private HttpServletResponse httpServletResponse;

    /**
     * 接口信息
     */
    private InterfaceBean interfaceBean;

    /**
     * 用户信息
     */
    private UserInfo userInfo;

    /**
     * 提供者ip和端口 ip:port
     */
    private String providerAddress;

    /**
     * 商户号
     */
    private String mchId;
}
