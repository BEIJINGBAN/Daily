package com.fingard.rh.rhf.yqs.saas.gateway.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * 通配符匹配数据
 *
 * @author Ruvik
 * @create 2022/09/22 10:23
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class UniversalDTO implements Serializable {
    private static final long serialVersionUID = 2736553408947392762L;

    /**
     * url
     */
    private String key;

    /**
     * 是否已经存在通配符
     */
    private boolean exist;
}
