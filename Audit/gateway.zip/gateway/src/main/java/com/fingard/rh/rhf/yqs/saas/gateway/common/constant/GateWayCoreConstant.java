package com.fingard.rh.rhf.yqs.saas.gateway.common.constant;

import com.fingard.rh.rhf.yqs.saas.common.beans.user.UserInfo;
import com.fingard.rh.rhf.yqs.saas.common.util.IdUtil;

/**
 * @author Ruvik
 * @create 2022/08/25 15:08
 */
public class GateWayCoreConstant {

    public static final String ENV_MARK_TEST = "test";

    public static final String ENV_MARK_UAT = "uat";

    public static final String TOKEN_FIELD = "token";

    public static final String CONSUMER_ADDRESS_FIELD = "consumerAddress";

    // 前段为空数据
    public static final String SEGMENT_NULL = "undefined";

    public static final String REFRESH_CACHE_URL = "/gateway/refreshCache";

    public static final String CHECK_USER_PERMISSION = "checkUserPermission";

    public static final String CHECK_PERMISSION_URL = "/webx/menu/checkUserPermission";

    public static final String HUI_SHAN_LOGIN = "/webx/online/systemindex/login/huiShanUserlogin.do";

    public static final String UAT_HUI_SHAN_LOGIN = "/uat/webx/online/systemindex/login/huiShanUserlogin.do";

//    public static final String UAT_CHECK_PERMISSION_URL = "/uat/webx/menu/checkUserPermission";

    /**
     * 上传文件中的type字段
     */
    public static final String UPLOAD_FILE_VALUE_TYPE = "fileInfo";

    public static final String UPLOAD_FILE_PARAM = "file";

    /**
     * 批量上传文件中的type字段
     */
    public static final String BATCH_UPLOAD_FILE_VALUE_TYPE = "fileList";

    public static final String BATCH_UPLOAD_FILE_PARAM = "files";

    public static final String SYSTEM_SIGN = "systemSign";


    public static final String MESSAGE_QUEUE = "YQS:GATEWAY:MESSAGE";

    public static final String MESSAGE_LOCK = "YQS:GATEWAY:MESSAGE:LOCK";


    public static final String SLASH = "/";

    public static final String MCH_ID = "mchId";

    public static final String SIGN_VALUE = "sign";

    public static final String SIGN_RSA_ALGORITHM = "SHA256withRSA";

    public static final String CHAR_SET = "utf-8";

    public static final String ACK_MARK = "{\"ack\":\"1\"}";

    public static final Integer MAX_QUEUE = 1000;

    public static String getFTPRandomFile(String ftpPrefix, UserInfo userInfoBean) {
        return ftpPrefix + "/importfile" + "/" + userInfoBean.getTenantCode() + "/" + userInfoBean.getSwitchOrgCode() + "/" + IdUtil.simpleUUID();
    }

    public static String getMessageQueue(String userId) {
        return MESSAGE_QUEUE + ":" + userId;
    }

    public static String getMessageLock(String message) {
        return MESSAGE_LOCK + ":" + message;
    }
}
