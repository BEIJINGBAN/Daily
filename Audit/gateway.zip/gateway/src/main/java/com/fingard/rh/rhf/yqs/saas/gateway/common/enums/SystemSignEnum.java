package com.fingard.rh.rhf.yqs.saas.gateway.common.enums;

import com.fingard.rh.rhf.yqs.saas.common.enums.LabelAndValue;

/**
 * @author Ruvik
 * @create 2022/11/16 14:14
 */
public enum SystemSignEnum implements LabelAndValue<String> {
    YQS_SAAS("YQS_SAAS", "易企收saas平台"),
    YUE_XIU_HUI_SHAN("YUE_XIU_HUI_SHAN", "越秀辉山内部平台");

    SystemSignEnum(String value, String label) {
        this.value = value;
        this.label = label;
    }

    private final String value;

    private final String label;

    @Override
    public String getValue() {
        return value;
    }

    @Override
    public String getLabel() {
        return label;
    }
}
