package com.fingard.rh.rhf.yqs.saas.gateway.biz.http;

import cn.hutool.core.util.ObjectUtil;
import com.fingard.rh.rhf.yqs.saas.common.beans.constant.RedisConstant;
import com.fingard.rh.rhf.yqs.saas.common.beans.ftp.FTPConfigBean;
import com.fingard.rh.rhf.yqs.saas.common.util.FtpUtil;
import com.fingard.rh.rhf.yqs.saas.gateway.dto.FtpInfoDTO;
import com.fingard.rh.rhf.yqs.saas.gateway.exception.GatewayException;
import com.fingard.rh.rhf.yqs.saas.gateway.manager.CacheManager;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.net.ftp.FTPClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.util.CollectionUtils;

import java.io.IOException;
import java.util.List;

/**
 * @author Ruvik
 * @create 2022/10/20 10:07
 */
@Slf4j
public abstract class FileServletHandle extends NormalServletHandle implements ServletHandle {

    @Autowired
    protected CacheManager cacheManager;

    @Value("${dubbo.registry.address}")
    protected String zkUrl;

    @Value("${ftp.prefix}")
    protected String ftpPrefix;

    /**
     * 获取ftp数据
     *
     * @param cacheManager
     * @return
     */
    protected FtpInfoDTO getFTPInfo(CacheManager cacheManager, String ftpKey) {
        FTPClient ftpClient = new FTPClient();
        if (!cacheManager.cacheBucketExist(RedisConstant.YQS_FTPCONFIG_CACHE)) {
            log.error("ftp的redis key不存在");
            throw new GatewayException("获取ftp链接异常");
        }
        List<FTPConfigBean> listFtpConfigBean = cacheManager.getCache(RedisConstant.YQS_FTPCONFIG_CACHE);
        if (CollectionUtils.isEmpty(listFtpConfigBean)) {
            log.error("获取ftp的redis信息失败");
            throw new GatewayException("获取ftp链接异常");
        }
        FTPConfigBean ftpConfigBean = listFtpConfigBean.stream().filter(x -> ftpKey.equals(x.getKey())).findFirst().orElse(null);
        if (ObjectUtil.isNull(ftpConfigBean)) {
            log.error("根据ftp key获取ftp信息失败");
            throw new GatewayException("获取ftp链接异常");
        }
        // redis拿数据
        if (!FtpUtil.connect(ftpClient, ftpConfigBean)) {
            log.error("获取ftp连接失败");
            throw new GatewayException("获取ftp链接异常");
        }
        return FtpInfoDTO.builder().ftpClient(ftpClient).ftpConfigBean(ftpConfigBean).build();
    }

    /**
     * 释放文件资源
     *
     * @param ftpClient
     * @throws IOException
     */
    protected void disconnectFtp(FTPClient ftpClient) {
        if (ObjectUtil.isNotNull(ftpClient)) {
            try {
                ftpClient.disconnect();
            } catch (Exception ex) {
                //源码里已经吃掉了，没有抛出来
            }
        }
    }

}
