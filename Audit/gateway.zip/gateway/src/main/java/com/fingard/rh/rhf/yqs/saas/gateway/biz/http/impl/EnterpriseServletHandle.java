package com.fingard.rh.rhf.yqs.saas.gateway.biz.http.impl;

import cn.hutool.core.util.ObjectUtil;
import cn.hutool.core.util.StrUtil;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.fingard.rh.rhf.yqs.saas.common.beans.BaseReturnResult;
import com.fingard.rh.rhf.yqs.saas.common.beans.constant.AuditRedisConstant;
import com.fingard.rh.rhf.yqs.saas.common.beans.gateway.InterfaceBean;
import com.fingard.rh.rhf.yqs.saas.common.beans.gateway.SignPublicBean;
import com.fingard.rh.rhf.yqs.saas.common.enums.HttpRequestMethodEnum;
import com.fingard.rh.rhf.yqs.saas.common.enums.YesOrNoEnum;
import com.fingard.rh.rhf.yqs.saas.gateway.biz.http.NormalServletHandle;
import com.fingard.rh.rhf.yqs.saas.gateway.common.constant.GateWayCoreConstant;
import com.fingard.rh.rhf.yqs.saas.gateway.dto.UrlHandleParam;
import com.fingard.rh.rhf.yqs.saas.gateway.exception.EnterpriseException;
import com.fingard.rh.rhf.yqs.saas.gateway.exception.SignErrorException;
import com.fingard.rh.rhf.yqs.saas.gateway.manager.CacheManager;
import com.fingard.rh.rhf.yqs.saas.gateway.util.SignUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;

import java.util.HashMap;

/**
 * 企业加解密实现类
 *
 * @author Ruvik
 * @create 2023/02/07 13:33
 */
@Service
@Slf4j
public class EnterpriseServletHandle extends NormalServletHandle {

    @Autowired
    private CacheManager cacheManager;

    @Value("${dubbo.registry.address}")
    private String zkUrl;

    @Override
    public boolean isSupport(UrlHandleParam urlHandleParam) {
        InterfaceBean interfaceBean = urlHandleParam.getInterfaceBean();
        return StrUtil.equals(interfaceBean.getIsFileInterface(), YesOrNoEnum.NO.getValue()) &&
                StrUtil.equals(interfaceBean.getIsOutside(), YesOrNoEnum.YES.getValue()) &&
                StrUtil.equals(HttpRequestMethodEnum.POST.getValue(), interfaceBean.getRequestType()) &&
                StrUtil.equals(interfaceBean.getContentType(), MediaType.APPLICATION_JSON_VALUE);
    }

    @Override
    public void handleUrlReq(UrlHandleParam urlHandleParam) {
        JSONObject jsonObject = null;
        try {
            Object result = getJsonParam(urlHandleParam);
            //这里对外只配成jsonString
            jsonObject = JSON.parseObject((String) result);
            String mchId = jsonObject.getString(GateWayCoreConstant.MCH_ID);
            log.info("待验签商户号: [{}]", mchId);
            urlHandleParam.setMchId(mchId);
            if (StrUtil.isEmpty(mchId)) {
                log.error("没有找到商户号");
                // 这里没有商户号
                throw new SignErrorException("无法找到商户号", null);
            }
            String signData = jsonObject.getString(GateWayCoreConstant.SIGN_VALUE);
            if (StrUtil.isBlank(signData)) {
                log.error("没有找到签名字段");
                // 这里没有签名字段
                throw new SignErrorException("签名字段没有传", mchId);
            }
            SignPublicBean signPublicBean = genSignPublicBean(AuditRedisConstant.getYqsBasePublickey(mchId), mchId);
            String publicKey = signPublicBean.getPublicKey();
            String saltValue = signPublicBean.getSaltValue();
            String signContent = SignUtil.genSignContentWithSalt(jsonObject, saltValue);
            log.info("验签参数:[{}]", signContent);
            if (StrUtil.isEmpty(publicKey) || StrUtil.isEmpty(saltValue)) {
                log.error("公钥配置异常,商户号:[{}]", mchId);
                throw new SignErrorException("出现异常", mchId);
            }
            boolean signResult = SignUtil.rsaVerify(signContent, signData, publicKey, GateWayCoreConstant.SIGN_RSA_ALGORITHM, GateWayCoreConstant.CHAR_SET);
            if (!signResult) {
                log.error("验签失败,商户号:[{}]", mchId);
                throw new SignErrorException("验签失败", mchId);
            }
            String zkAddress = getZkAddress(zkUrl, mchId, urlHandleParam, cacheManager);
            callDubbo(urlHandleParam, zkAddress, jsonObject.toJSONString());
        } catch (Exception e) {
            if (ObjectUtil.isNotNull(jsonObject)) {
                log.error("当前请求参数:[{}]", jsonObject.toJSONString());
            } else {
                log.error("当前请求参数为空, urlHandleParam: [{}]", urlHandleParam);
            }

            throw new EnterpriseException("企业处理类出现异常", e);
        }
    }

    @Override
    public void dealTheDubboResult(Object result, UrlHandleParam urlHandleParam) {
        // 只有是这个类型的需要加签
        if (result instanceof HashMap) {
            setSign(urlHandleParam.getMchId(), (HashMap) result);
        }

        writeResult(result, urlHandleParam.getHttpServletResponse());
    }

    private SignPublicBean genSignPublicBean(String key, String mchId) {
        SignPublicBean signPublicBean = cacheManager.getCache(key);
        if (ObjectUtil.isNull(signPublicBean)) {
            log.error("从redis缓存中获取SignPublicBean对象为空，向上抛出异常。缓存key: [{}], 商户号(或者企业号): [{}]", key, mchId);
            throw new SignErrorException("获取公钥失败", mchId);
        }
        return signPublicBean;
    }

    private void setSign(String mchId, HashMap openApiBaseResponse) {
        BaseReturnResult<String> result = getSign(mchId, JSON.toJSONString(openApiBaseResponse));
        String sign = result.getObject();
        log.info("当前请求添加的sign:[{}],[{}]", openApiBaseResponse, sign);
        // 添加返回签名
        openApiBaseResponse.put("sign", result.getObject());
    }

    private BaseReturnResult<String> getSign(String mchId, String jsonData) {
        try {
            if (StrUtil.isBlank(mchId)) {
                log.error("企业号不能为空");
                return BaseReturnResult.getFailResult("企业号不能为空");
            }
            SignPublicBean signPublicBean = genSignPublicBean(AuditRedisConstant.getYqsBasePublickey(mchId), mchId);
            if (ObjectUtil.isNull(signPublicBean)) {
                return BaseReturnResult.getFailResult("获取密钥失败");
            }
            // 保融私钥加密
            String brPrivateKey = signPublicBean.getBrPrivateKey();
            String saltValue = signPublicBean.getSaltValue();
            JSONObject jsonObject = JSON.parseObject(jsonData);
            String signContent = SignUtil.genSignContentWithSalt(jsonObject, saltValue);
            log.info("签名参数:[{}]", signContent);
            String result = SignUtil.rsaSign(signContent, brPrivateKey, GateWayCoreConstant.SIGN_RSA_ALGORITHM, GateWayCoreConstant.CHAR_SET);
            if (StrUtil.isNotBlank(result)) {
                return BaseReturnResult.success(result);
            }
        } catch (Exception e) {
            log.error("加签方法出现异常", e);
        }
        return BaseReturnResult.getFailResult("加签失败");
    }

}
