package com.fingard.rh.rhf.yqs.saas.gateway.listener;

import com.fingard.rh.rhf.yqs.saas.gateway.manager.CacheManager;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.stereotype.Service;

/**
 * @author Ruvik
 * @create 2022/10/11 14:23
 */
@Slf4j
@Service
public class CacheInitListener implements ApplicationRunner {

    @Autowired
    private CacheManager cacheManager;

    @Override
    public void run(ApplicationArguments args) {
        // 初始化缓存
        cacheManager.refreshCache();
        // 添加监听topic
        cacheManager.addListener();
//        cacheManager.addRepeatLoginListener();
    }
}
