package com.fingard.rh.rhf.yqs.saas.gateway.conf.sentinel;

import com.alibaba.csp.sentinel.adapter.servlet.CommonFilter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.condition.ConditionalOnExpression;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import javax.servlet.Filter;

/**
 * @author tianzh
 * @date 2022/10/18
 */
@Configuration
@Slf4j
public class SentinelConfiguration {

    /**
     * 只有当配置了sentinel控制台地址时 才注入过滤器启用sentinel功能
     *
     * @return {@link FilterRegistrationBean}<{@link Filter}>
     */
    @Bean
    @ConditionalOnExpression("T(cn.hutool.core.util.StrUtil).isNotBlank('${csp.sentinel.dashboard.server}')")
    public FilterRegistrationBean<Filter> sentinelFilterRegistration() {
        FilterRegistrationBean<Filter> registration = new FilterRegistrationBean<>();
        registration.setFilter(new CommonFilter());
        registration.addUrlPatterns("/*");
        registration.setName("sentinelFilter");
        registration.setOrder(1);
        log.info("注册Sentinel过滤器成功！");
        return registration;
    }
}
