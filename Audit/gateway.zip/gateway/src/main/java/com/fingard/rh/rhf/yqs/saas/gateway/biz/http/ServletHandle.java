package com.fingard.rh.rhf.yqs.saas.gateway.biz.http;

import cn.hutool.core.collection.CollectionUtil;
import cn.hutool.core.util.StrUtil;
import cn.hutool.extra.spring.SpringUtil;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.serializer.PropertyFilter;
import com.alibaba.fastjson.serializer.SerializeFilter;
import com.alibaba.fastjson.serializer.SerializerFeature;
import com.alibaba.fastjson.serializer.ValueFilter;
import com.fingard.rh.rhf.yqs.saas.common.annotation.amt.Amount;
import com.fingard.rh.rhf.yqs.saas.common.annotation.amt.AmountFormmatter;
import com.fingard.rh.rhf.yqs.saas.common.beans.gateway.InterfaceBean;
import com.fingard.rh.rhf.yqs.saas.common.enums.GateWayParamTypeEnum;
import com.fingard.rh.rhf.yqs.saas.gateway.dto.UrlHandleParam;
import com.fingard.rh.rhf.yqs.saas.gateway.util.CommonUtil;
import com.fingard.rh.rhf.yqs.saas.gateway.util.IOUtil;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.reflect.FieldUtils;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.lang.reflect.Field;
import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * 处理不同类型的http
 *
 * @author Ruvik
 * @create 2022/07/25 10:20
 */
public interface ServletHandle {

    JsonFilter jsonFilter = new JsonFilter();

    JsonValueFilter jsonValueFilter = new JsonValueFilter();

    /**
     * 用来判断当前实现是不是适配
     *
     * @param urlHandleParam
     * @return
     */
    boolean isSupport(UrlHandleParam urlHandleParam);

    /**
     * 处理业务请求
     *
     * @param urlHandleParam
     * @throws IOException
     */
    void handleUrlReq(UrlHandleParam urlHandleParam);

    /**
     * 处理dubbo返回的结果
     *
     * @param result
     * @param urlHandleParam
     * @throws IOException
     */
    void dealTheDubboResult(Object result, UrlHandleParam urlHandleParam);

    /**
     * 处理dubbo调用，同步或者异步，默认同步
     *
     * @return
     */
    default void callDubbo(UrlHandleParam urlHandleParam, String zkUrl, Object param) {
        InterfaceBean interFaceBean = urlHandleParam.getInterfaceBean();
        String[] paramType = StrUtil.isEmpty(interFaceBean.getParamType()) ? new String[0] :
                (GateWayParamTypeEnum.JSON_PARAM.getValue().equals(interFaceBean.getParamType()) || GateWayParamTypeEnum.XML_PARAM.getValue().equals(interFaceBean.getParamType())) ?
                        new String[]{"java.lang.String"} : new String[]{interFaceBean.getParamType()};
        Object[] data = StrUtil.isEmpty(interFaceBean.getParamType()) ? new Object[0] : new Object[]{param};
        dealTheDubboResult(CommonUtil.generic(interFaceBean, zkUrl, paramType, data, urlHandleParam.getProviderAddress(), urlHandleParam.getUserInfo()), urlHandleParam);
    }

    /**
     * 处理结果
     *
     * @param result
     * @param httpServletResponse
     * @throws IOException
     */
    default void writeResult(Object result, HttpServletResponse httpServletResponse) {
        String json;
        if (result instanceof String) {
            json = (String) result;
        } else {
            json = JSON.toJSONString(result, new SerializeFilter[]{jsonFilter, jsonValueFilter}, SerializerFeature.WriteMapNullValue);
        }
        IOUtil.writeResult(json, httpServletResponse);
    }

    /**
     * form参数处理
     *
     * @param urlHandleParam
     * @return
     */
    default Object getParam(UrlHandleParam urlHandleParam) {
        Map<String, String[]> map = urlHandleParam.getHttpServletRequest().getParameterMap();
        InterfaceBean interfaceBean = urlHandleParam.getInterfaceBean();
        if (StrUtil.isEmpty(interfaceBean.getParamType())) {
            throw new RuntimeException("泛化参数类型为空");
        }
        Map<String, String> paramMap = new HashMap<>();
        for (Map.Entry<String, String[]> entry : map.entrySet()) {
            String k = entry.getKey();
            String result = entry.getValue()[0];
            if (StrUtil.equals(GateWayParamTypeEnum.INTEGER_PARAM.getValue(), interfaceBean.getParamType())) {
                return Integer.parseInt(result);
            } else if (StrUtil.equals(GateWayParamTypeEnum.LONG_PARAM.getValue(), interfaceBean.getParamType())) {
                return Long.parseLong(result);
            } else if (StrUtil.equals(GateWayParamTypeEnum.STRING_PARAM.getValue(), interfaceBean.getParamType())) {
                return result;
            } else if (StrUtil.equals(GateWayParamTypeEnum.LIST_PARAM.getValue(), interfaceBean.getParamType())) {
                return CollectionUtil.newArrayList(result.split(","));
            } else if (interfaceBean.getParamType().contains(GateWayParamTypeEnum.BEAN_PARAM.getValue()) ||
                    StrUtil.equals(interfaceBean.getParamType(), GateWayParamTypeEnum.MAP_PARAM.getValue())) {
                paramMap.put(k, result);
            } else {
                throw new RuntimeException("不支持的参数类型");
            }
        }
        return paramMap;
    }

    class JsonFilter implements PropertyFilter {
        @Override
        public boolean apply(Object object, String name, Object value) {
            // 包含该字段或值
            return !name.equals("class");
        }
    }

    class JsonValueFilter implements ValueFilter {
        @Override
        public Object process(Object object, String name, Object value) {
            if (value instanceof BigDecimal) {
                return this.processBigDecimal(object, name, value);
            }

            if (value instanceof Date) {
                return this.processDate(object, name, value);
            }

            if (value instanceof Long) {
                return String.valueOf(value);
            }

            return value;
        }

        private Object processDate(Object object, String name, Object value) {
            try {
                Field field = FieldUtils.getField(object.getClass(), name, true);
                if (!field.isAnnotationPresent(com.fingard.rh.rhf.yqs.saas.common.annotation.Date.class)) {
                    return value;
                }
                com.fingard.rh.rhf.yqs.saas.common.annotation.Date annotation = field.getAnnotation(com.fingard.rh.rhf.yqs.saas.common.annotation.Date.class);
                String pattern = annotation.pattern();
                if (StringUtils.isBlank(pattern)) {
                    return value;
                }
                return new SimpleDateFormat(pattern).format((Date) value);
            } catch (Exception e) {
                return value;
            }
        }

        private Object processBigDecimal(Object object, String name, Object value) {
            try {
                Field field = FieldUtils.getField(object.getClass(), name, true);
                if (!field.isAnnotationPresent(Amount.class)) {
                    return this.formatBigDecimal(value);
                }
                Amount annotation = field.getAnnotation(Amount.class);
                Class<? extends AmountFormmatter> formatter = annotation.formatter();
                if (formatter == null) {
                    return this.formatBigDecimal(value);
                }

                AmountFormmatter bean = SpringUtil.getBean(formatter); // 怎么样从 AmountFormatter 拿到实际的处理类
                return bean.format2String((BigDecimal) value);
            } catch (Exception e) {
                return this.formatBigDecimal(value);
            }
        }

        // 老的逻辑，必须兼容
        private Object formatBigDecimal(Object value) {
            if (value instanceof BigDecimal) {
                return new DecimalFormat("0.00").format(value);
            }
            return value;
        }
    }
}
