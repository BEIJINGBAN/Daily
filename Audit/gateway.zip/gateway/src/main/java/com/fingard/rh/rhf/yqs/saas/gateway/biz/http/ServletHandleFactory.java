package com.fingard.rh.rhf.yqs.saas.gateway.biz.http;

import com.fingard.rh.rhf.yqs.saas.gateway.dto.UrlHandleParam;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * @author Ruvik
 * @create 2022/07/25 11:12
 */
@Component
@Slf4j
public class ServletHandleFactory {

    @Autowired
    private List<ServletHandle> listServletHandle;

    public ServletHandle getServletHandle(UrlHandleParam urlHandleParam) {
        for (ServletHandle servletHandle : listServletHandle) {
            if (servletHandle.isSupport(urlHandleParam)) {
                log.info("匹配到处理类:[{}]", servletHandle.getClass().getName());
                return servletHandle;
            }
        }
        return null;
    }
}
